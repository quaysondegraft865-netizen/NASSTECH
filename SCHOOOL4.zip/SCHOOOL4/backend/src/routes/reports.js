import express from 'express';
import { query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher } from '../middleware/auth.js';
import * as reportController from '../controllers/reportController.js';

const router = express.Router();

router.get('/student/:studentId/transcript', [
  authenticate(),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  query('academic_year_id').optional().isUUID(),
  validate
], reportController.getStudentTranscript);

router.get('/student/:studentId/report-card', [
  authenticate(),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  query('academic_year_id').isUUID().withMessage('Academic year ID required'),
  query('semester_id').isUUID().withMessage('Semester ID required'),
  validate
], reportController.getStudentReportCard);

router.get('/class/:classId/grade-sheet', [
  authenticate(),
  requireTeacher(),
  param('classId').isUUID().withMessage('Invalid class ID'),
  query('subject_id').isUUID().withMessage('Subject ID required'),
  query('academic_year_id').isUUID().withMessage('Academic year ID required'),
  query('semester_id').isUUID().withMessage('Semester ID required'),
  validate
], reportController.getClassGradeSheet);

router.get('/class/:classId/attendance-summary', [
  authenticate(),
  requireTeacher(),
  param('classId').isUUID().withMessage('Invalid class ID'),
  query('start_date').isISO8601().withMessage('Start date required'),
  query('end_date').isISO8601().withMessage('End date required'),
  query('subject_id').optional().isUUID(),
  validate
], reportController.getClassAttendanceSummary);

router.get('/teacher/:teacherId/workload', [
  authenticate(),
  requireAdmin(),
  param('teacherId').isUUID().withMessage('Invalid teacher ID'),
  query('academic_year_id').optional().isUUID(),
  validate
], reportController.getTeacherWorkload);

router.get('/fees/collection', [
  authenticate(),
  requireAdmin(),
  query('academic_year_id').optional().isUUID(),
  query('start_date').optional().isISO8601().withMessage('Valid start date required'),
  query('end_date').optional().isISO8601().withMessage('Valid end date required'),
  validate
], reportController.getFeeCollectionReport);

router.get('/enrollment/summary', [
  authenticate(),
  requireAdmin(),
  query('academic_year_id').optional().isUUID(),
  validate
], reportController.getEnrollmentSummary);

router.get('/academic/performance', [
  authenticate(),
  requireAdmin(),
  query('academic_year_id').isUUID().withMessage('Academic year ID required'),
  query('semester_id').optional().isUUID(),
  validate
], reportController.getAcademicPerformance);

export default router;