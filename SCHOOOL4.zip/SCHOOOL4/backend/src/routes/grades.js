import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher, requireStudent } from '../middleware/auth.js';
import * as gradeController from '../controllers/gradeController.js';

const router = express.Router();

router.get('/', [
  authenticate(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('student_id').optional().isUUID(),
  query('subject_id').optional().isUUID(),
  query('class_id').optional().isUUID(),
  query('academic_year_id').optional().isUUID(),
  query('semester_id').optional().isUUID(),
  validate
], gradeController.getAllGrades);

router.get('/summary/:studentId', [
  authenticate(),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  query('academic_year_id').optional().isUUID(),
  query('semester_id').optional().isUUID(),
  validate
], gradeController.getStudentGradeSummary);

router.get('/class/:classId', [
  authenticate(),
  requireTeacher(),
  param('classId').isUUID().withMessage('Invalid class ID'),
  query('subject_id').optional().isUUID(),
  query('academic_year_id').optional().isUUID(),
  query('semester_id').optional().isUUID(),
  validate
], gradeController.getClassGrades);

router.get('/:id', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid grade ID'),
  validate
], gradeController.getGradeById);

router.post('/', [
  authenticate(),
  requireTeacher(),
  body('student_id').isUUID().withMessage('Valid student ID required'),
  body('subject_id').isUUID().withMessage('Valid subject ID required'),
  body('class_id').isUUID().withMessage('Valid class ID required'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('semester_id').isUUID().withMessage('Valid semester ID required'),
  body('ca_score').optional().isFloat({ min: 0, max: 100 }).withMessage('CA score must be between 0 and 100'),
  body('exam_score').optional().isFloat({ min: 0, max: 100 }).withMessage('Exam score must be between 0 and 100'),
  body('remarks').optional().isString(),
  validate
], gradeController.createOrUpdateGrade);

router.post('/bulk', [
  authenticate(),
  requireTeacher(),
  body('grades').isArray({ min: 1 }).withMessage('Grades array is required'),
  body('grades.*.student_id').isUUID().withMessage('Valid student ID required'),
  body('grades.*.subject_id').isUUID().withMessage('Valid subject ID required'),
  body('grades.*.class_id').isUUID().withMessage('Valid class ID required'),
  body('grades.*.academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('grades.*.semester_id').isUUID().withMessage('Valid semester ID required'),
  body('grades.*.ca_score').optional().isFloat({ min: 0, max: 100 }),
  body('grades.*.exam_score').optional().isFloat({ min: 0, max: 100 }),
  body('grades.*.remarks').optional().isString(),
  validate
], gradeController.bulkCreateGrades);

router.put('/:id', [
  authenticate(),
  requireTeacher(),
  param('id').isUUID().withMessage('Invalid grade ID'),
  body('ca_score').optional().isFloat({ min: 0, max: 100 }).withMessage('CA score must be between 0 and 100'),
  body('exam_score').optional().isFloat({ min: 0, max: 100 }).withMessage('Exam score must be between 0 and 100'),
  body('remarks').optional().isString(),
  validate
], gradeController.updateGrade);

router.delete('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid grade ID'),
  validate
], gradeController.deleteGrade);

export default router;