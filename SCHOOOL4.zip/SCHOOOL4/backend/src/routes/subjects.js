import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher } from '../middleware/auth.js';
import * as subjectController from '../controllers/subjectController.js';

const router = express.Router();

router.get('/', [
  authenticate(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('search').optional().isString(),
  query('department').optional().isString(),
  query('is_active').optional().isBoolean(),
  validate
], subjectController.getAllSubjects);

router.get('/:id', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid subject ID'),
  validate
], subjectController.getSubjectById);

router.post('/', [
  authenticate(),
  requireAdmin(),
  body('code').notEmpty().withMessage('Subject code is required'),
  body('name').notEmpty().withMessage('Subject name is required'),
  body('department').optional().isString(),
  body('credits').optional().isInt({ min: 1 }).withMessage('Credits must be a positive integer'),
  body('description').optional().isString(),
  validate
], subjectController.createSubject);

router.put('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid subject ID'),
  body('code').optional().notEmpty().withMessage('Subject code cannot be empty'),
  body('name').optional().notEmpty().withMessage('Subject name cannot be empty'),
  body('department').optional().isString(),
  body('credits').optional().isInt({ min: 1 }).withMessage('Credits must be a positive integer'),
  body('description').optional().isString(),
  body('is_active').optional().isBoolean(),
  validate
], subjectController.updateSubject);

router.delete('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid subject ID'),
  validate
], subjectController.deleteSubject);

router.get('/:id/classes', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid subject ID'),
  query('academic_year_id').optional().isUUID(),
  validate
], subjectController.getSubjectClasses);

export default router;