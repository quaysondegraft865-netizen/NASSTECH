import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher } from '../middleware/auth.js';
import * as teacherController from '../controllers/teacherController.js';

const router = express.Router();

router.get('/', [
  authenticate(),
  requireAdmin(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('search').optional().isString(),
  query('department').optional().isString(),
  query('designation').optional().isString(),
  validate
], teacherController.getAllTeachers);

router.get('/:id', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid teacher ID'),
  validate
], teacherController.getTeacherById);

router.post('/', [
  authenticate(),
  requireAdmin(),
  body('staff_id').notEmpty().withMessage('Staff ID is required'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  body('full_name').notEmpty().withMessage('Full name is required'),
  body('role').isIn(['teacher', 'form_master', 'hod']).withMessage('Role must be teacher, form_master, or hod'),
  body('department').notEmpty().withMessage('Department is required'),
  body('designation').optional().isString(),
  body('qualification').optional().isString(),
  body('specialization').optional().isString(),
  body('hire_date').isISO8601().withMessage('Valid hire date is required'),
  body('salary_grade').optional().isString(),
  body('max_workload').optional().isInt({ min: 1, max: 40 }).withMessage('Max workload must be between 1 and 40'),
  body('phone').optional().isMobilePhone().withMessage('Valid phone number required'),
  validate
], teacherController.createTeacher);

router.put('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid teacher ID'),
  body('email').optional().isEmail().withMessage('Valid email is required'),
  body('full_name').optional().notEmpty().withMessage('Full name cannot be empty'),
  body('phone').optional().isMobilePhone().withMessage('Valid phone number required'),
  body('role').optional().isIn(['teacher', 'form_master', 'hod']),
  body('department').optional().isString(),
  body('designation').optional().isString(),
  body('qualification').optional().isString(),
  body('specialization').optional().isString(),
  body('salary_grade').optional().isString(),
  body('max_workload').optional().isInt({ min: 1, max: 40 }),
  validate
], teacherController.updateTeacher);

router.delete('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid teacher ID'),
  validate
], teacherController.deleteTeacher);

router.get('/:id/assignments', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid teacher ID'),
  query('academic_year_id').optional().isUUID(),
  validate
], teacherController.getTeacherAssignments);

router.get('/:id/classes', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid teacher ID'),
  query('academic_year_id').optional().isUUID(),
  validate
], teacherController.getTeacherClasses);

router.post('/:id/assign', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid teacher ID'),
  body('class_id').isUUID().withMessage('Valid class ID required'),
  body('subject_id').isUUID().withMessage('Valid subject ID required'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('periods_per_week').optional().isInt({ min: 1, max: 20 }).withMessage('Periods per week must be between 1 and 20'),
  validate
], teacherController.assignTeacher);

router.delete('/:id/assignments/:assignmentId', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid teacher ID'),
  param('assignmentId').isUUID().withMessage('Invalid assignment ID'),
  validate
], teacherController.removeAssignment);

export default router;