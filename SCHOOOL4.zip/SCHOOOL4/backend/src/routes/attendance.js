import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher, requireStudent } from '../middleware/auth.js';
import * as attendanceController from '../controllers/attendanceController.js';

const router = express.Router();

router.get('/', [
  authenticate(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('student_id').optional().isUUID(),
  query('class_id').optional().isUUID(),
  query('subject_id').optional().isUUID(),
  query('start_date').optional().isISO8601().withMessage('Valid start date required'),
  query('end_date').optional().isISO8601().withMessage('Valid end date required'),
  query('status').optional().isIn(['present', 'absent', 'late', 'excused']),
  validate
], attendanceController.getAllAttendance);

router.get('/stats/:studentId', [
  authenticate(),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  query('start_date').optional().isISO8601().withMessage('Valid start date required'),
  query('end_date').optional().isISO8601().withMessage('Valid end date required'),
  query('subject_id').optional().isUUID(),
  validate
], attendanceController.getStudentAttendanceStats);

router.get('/class/:classId', [
  authenticate(),
  requireTeacher(),
  param('classId').isUUID().withMessage('Invalid class ID'),
  query('subject_id').optional().isUUID(),
  query('date').optional().isISO8601().withMessage('Valid date required'),
  validate
], attendanceController.getClassAttendance);

router.post('/', [
  authenticate(),
  requireTeacher(),
  body('student_id').isUUID().withMessage('Valid student ID required'),
  body('class_id').isUUID().withMessage('Valid class ID required'),
  body('subject_id').isUUID().withMessage('Valid subject ID required'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('date').isISO8601().withMessage('Valid date required'),
  body('status').isIn(['present', 'absent', 'late', 'excused']).withMessage('Invalid status'),
  validate
], attendanceController.recordAttendance);

router.post('/bulk', [
  authenticate(),
  requireTeacher(),
  body('records').isArray({ min: 1 }).withMessage('Records array is required'),
  body('records.*.student_id').isUUID().withMessage('Valid student ID required'),
  body('records.*.class_id').isUUID().withMessage('Valid class ID required'),
  body('records.*.subject_id').isUUID().withMessage('Valid subject ID required'),
  body('records.*.academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('records.*.date').isISO8601().withMessage('Valid date required'),
  body('records.*.status').isIn(['present', 'absent', 'late', 'excused']).withMessage('Invalid status'),
  validate
], attendanceController.bulkRecordAttendance);

router.put('/:id', [
  authenticate(),
  requireTeacher(),
  param('id').isUUID().withMessage('Invalid attendance ID'),
  body('status').optional().isIn(['present', 'absent', 'late', 'excused']).withMessage('Invalid status'),
  validate
], attendanceController.updateAttendance);

router.delete('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid attendance ID'),
  validate
], attendanceController.deleteAttendance);

export default router;