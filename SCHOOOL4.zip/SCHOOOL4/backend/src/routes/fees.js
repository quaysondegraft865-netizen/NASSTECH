import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireStudent } from '../middleware/auth.js';
import * as feeController from '../controllers/feeController.js';

const router = express.Router();

router.get('/structure', [
  authenticate(),
  requireAdmin(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('academic_year_id').optional().isUUID(),
  query('class_level').optional().isString(),
  query('programme').optional().isString(),
  validate
], feeController.getFeeStructures);

router.post('/structure', [
  authenticate(),
  requireAdmin(),
  body('name').notEmpty().withMessage('Fee name is required'),
  body('amount').isFloat({ min: 0 }).withMessage('Amount must be a positive number'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('description').optional().isString(),
  body('class_level').optional().isString(),
  body('programme').optional().isString(),
  body('is_mandatory').optional().isBoolean(),
  body('due_date').optional().isISO8601().withMessage('Valid due date required'),
  validate
], feeController.createFeeStructure);

router.put('/structure/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid fee structure ID'),
  body('name').optional().notEmpty().withMessage('Fee name cannot be empty'),
  body('amount').optional().isFloat({ min: 0 }).withMessage('Amount must be a positive number'),
  body('description').optional().isString(),
  body('class_level').optional().isString(),
  body('programme').optional().isString(),
  body('is_mandatory').optional().isBoolean(),
  body('due_date').optional().isISO8601().withMessage('Valid due date required'),
  validate
], feeController.updateFeeStructure);

router.delete('/structure/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid fee structure ID'),
  validate
], feeController.deleteFeeStructure);

router.get('/student/:studentId', [
  authenticate(),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  query('academic_year_id').optional().isUUID(),
  query('status').optional().isIn(['pending', 'partial', 'paid', 'overdue', 'waived']),
  validate
], feeController.getStudentFees);

router.post('/student/:studentId/assign', [
  authenticate(),
  requireAdmin(),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  body('fee_structure_id').isUUID().withMessage('Valid fee structure ID required'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('amount_due').optional().isFloat({ min: 0 }),
  body('due_date').optional().isISO8601().withMessage('Valid due date required'),
  validate
], feeController.assignFeeToStudent);

router.post('/payment', [
  authenticate(),
  requireAdmin(),
  body('student_id').isUUID().withMessage('Valid student ID required'),
  body('student_fee_id').optional().isUUID(),
  body('amount').isFloat({ min: 0.01 }).withMessage('Amount must be greater than 0'),
  body('payment_method').optional().isString(),
  body('reference').optional().isString(),
  body('description').optional().isString(),
  validate
], feeController.recordPayment);

router.get('/payments/:studentId', [
  authenticate(),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  validate
], feeController.getStudentPayments);

router.get('/overdue', [
  authenticate(),
  requireAdmin(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  validate
], feeController.getOverdueFees);

export default router;