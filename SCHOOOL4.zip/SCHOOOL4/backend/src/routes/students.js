import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher, requireStudent } from '../middleware/auth.js';
import * as studentController from '../controllers/studentController.js';

const router = express.Router();

router.get('/', [
  authenticate(),
  requireAdmin(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('search').optional().isString(),
  query('programme').optional().isString(),
  query('level').optional().isString(),
  query('status').optional().isString(),
  validate
], studentController.getAllStudents);

router.get('/:id', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid student ID'),
  validate
], studentController.getStudentById);

router.post('/', [
  authenticate(),
  requireAdmin(),
  body('student_id').notEmpty().withMessage('Student ID is required'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  body('full_name').notEmpty().withMessage('Full name is required'),
  body('programme').notEmpty().withMessage('Programme is required'),
  body('level').notEmpty().withMessage('Level is required'),
  body('admission_year').notEmpty().withMessage('Admission year is required'),
  body('date_of_birth').isISO8601().withMessage('Valid date of birth is required'),
  body('gender').isIn(['male', 'female']).withMessage('Gender must be male or female'),
  body('phone').optional().isMobilePhone().withMessage('Valid phone number required'),
  body('guardian_name').optional().isString(),
  body('guardian_phone').optional().isMobilePhone().withMessage('Valid guardian phone required'),
  body('guardian_email').optional().isEmail().withMessage('Valid guardian email required'),
  body('address').optional().isString(),
  body('department').optional().isString(),
  validate
], studentController.createStudent);

router.put('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid student ID'),
  body('email').optional().isEmail().withMessage('Valid email is required'),
  body('full_name').optional().notEmpty().withMessage('Full name cannot be empty'),
  body('phone').optional().isMobilePhone().withMessage('Valid phone number required'),
  body('programme').optional().isString(),
  body('level').optional().isString(),
  body('status').optional().isIn(['active', 'dropped', 'graduated', 'transferred']),
  body('guardian_name').optional().isString(),
  body('guardian_phone').optional().isMobilePhone().withMessage('Valid guardian phone required'),
  body('guardian_email').optional().isEmail().withMessage('Valid guardian email required'),
  body('address').optional().isString(),
  body('department').optional().isString(),
  validate
], studentController.updateStudent);

router.delete('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid student ID'),
  validate
], studentController.deleteStudent);

router.get('/:id/enrollments', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid student ID'),
  validate
], studentController.getStudentEnrollments);

router.get('/:id/grades', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid student ID'),
  query('academic_year_id').optional().isUUID(),
  query('semester_id').optional().isUUID(),
  validate
], studentController.getStudentGrades);

router.get('/:id/attendance', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid student ID'),
  query('start_date').optional().isISO8601().withMessage('Valid start date required'),
  query('end_date').optional().isISO8601().withMessage('Valid end date required'),
  query('subject_id').optional().isUUID(),
  validate
], studentController.getStudentAttendance);

router.get('/:id/fees', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid student ID'),
  query('academic_year_id').optional().isUUID(),
  validate
], studentController.getStudentFees);

router.post('/bulk-import', [
  authenticate(),
  requireAdmin(),
  body('students').isArray({ min: 1 }).withMessage('Students array is required'),
  validate
], studentController.bulkImportStudents);

export default router;