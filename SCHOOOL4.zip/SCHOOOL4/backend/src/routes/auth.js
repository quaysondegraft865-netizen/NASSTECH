import express from 'express';
import { body } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate } from '../middleware/auth.js';
import * as authController from '../controllers/authController.js';

const router = express.Router();

router.post('/student/login', [
  body('username').notEmpty().withMessage('Student ID or email is required'),
  body('password').notEmpty().withMessage('Password is required'),
  validate
], authController.studentLogin);

router.post('/teacher/login', [
  body('staffId').notEmpty().withMessage('Staff ID is required'),
  body('password').notEmpty().withMessage('Password is required'),
  validate
], authController.teacherLogin);

router.post('/admin/login', [
  body('adminId').notEmpty().withMessage('Admin email is required'),
  body('password').notEmpty().withMessage('Password is required'),
  body('otp').notEmpty().withMessage('2FA code is required'),
  validate
], authController.adminLogin);

router.post('/refresh', [
  body('refreshToken').notEmpty().withMessage('Refresh token is required'),
  validate
], authController.refreshToken);

router.get('/profile', authenticate(), authController.getProfile);

router.put('/password', [
  authenticate(),
  body('currentPassword').notEmpty().withMessage('Current password is required'),
  body('newPassword').isLength({ min: 8 }).withMessage('New password must be at least 8 characters'),
  validate
], authController.changePassword);

router.post('/logout', authenticate(), authController.logout);

export default router;