import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher } from '../middleware/auth.js';
import * as classController from '../controllers/classController.js';

const router = express.Router();

router.get('/', [
  authenticate(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('search').optional().isString(),
  query('form_level').optional().isString(),
  query('programme').optional().isString(),
  query('academic_year_id').optional().isUUID(),
  validate
], classController.getAllClasses);

router.get('/:id', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid class ID'),
  validate
], classController.getClassById);

router.post('/', [
  authenticate(),
  requireAdmin(),
  body('name').notEmpty().withMessage('Class name is required'),
  body('code').notEmpty().withMessage('Class code is required'),
  body('form_level').notEmpty().withMessage('Form level is required'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('programme').optional().isString(),
  body('capacity').optional().isInt({ min: 1, max: 100 }).withMessage('Capacity must be between 1 and 100'),
  body('form_teacher_id').optional().isUUID().withMessage('Valid form teacher ID required'),
  validate
], classController.createClass);

router.put('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid class ID'),
  body('name').optional().notEmpty().withMessage('Class name cannot be empty'),
  body('code').optional().notEmpty().withMessage('Class code cannot be empty'),
  body('form_level').optional().notEmpty().withMessage('Form level cannot be empty'),
  body('programme').optional().isString(),
  body('capacity').optional().isInt({ min: 1, max: 100 }),
  body('form_teacher_id').optional().isUUID().withMessage('Valid form teacher ID required'),
  validate
], classController.updateClass);

router.delete('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid class ID'),
  validate
], classController.deleteClass);

router.get('/:id/students', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid class ID'),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  validate
], classController.getClassStudents);

router.get('/:id/subjects', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid class ID'),
  query('academic_year_id').optional().isUUID(),
  validate
], classController.getClassSubjects);

router.post('/:id/subjects', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid class ID'),
  body('subject_id').isUUID().withMessage('Valid subject ID required'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('periods_per_week').optional().isInt({ min: 1, max: 20 }).withMessage('Periods per week must be between 1 and 20'),
  validate
], classController.addClassSubject);

router.delete('/:id/subjects/:subjectId', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid class ID'),
  param('subjectId').isUUID().withMessage('Invalid subject ID'),
  query('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  validate
], classController.removeClassSubject);

router.post('/:id/enroll', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid class ID'),
  body('student_ids').isArray({ min: 1 }).withMessage('At least one student ID required'),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  validate
], classController.enrollStudents);

router.delete('/:id/enroll/:studentId', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid class ID'),
  param('studentId').isUUID().withMessage('Invalid student ID'),
  query('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  validate
], classController.removeStudent);

export default router;