import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireSuperAdmin } from '../middleware/auth.js';
import * as adminController from '../controllers/adminController.js';

const router = express.Router();

// Dashboard
router.get('/dashboard', [
  authenticate(),
  requireAdmin(),
  validate
], adminController.getDashboardStats);

// Activity logs
router.get('/activity-logs', [
  authenticate(),
  requireAdmin(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('action').optional().isString(),
  query('entity_type').optional().isString(),
  validate
], adminController.getActivityLogs);

// User management
router.get('/users', [
  authenticate(),
  requireAdmin(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('search').optional().isString(),
  query('role').optional().isIn(['student', 'teacher', 'form_master', 'hod', 'staff', 'super_admin']),
  query('is_active').optional().isBoolean(),
  validate
], adminController.getAllUsers);

router.put('/users/:id/activate', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid user ID'),
  validate
], adminController.activateUser);

router.put('/users/:id/deactivate', [
  authenticate(),
  requireSuperAdmin(),
  param('id').isUUID().withMessage('Invalid user ID'),
  validate
], adminController.deactivateUser);

// Academic years
router.get('/academic-years', [
  authenticate(),
  requireAdmin(),
  validate
], adminController.getAllAcademicYears);

router.get('/academic-years/:id', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid academic year ID'),
  validate
], adminController.getAcademicYearById);

router.post('/academic-years', [
  authenticate(),
  requireSuperAdmin(),
  body('name').notEmpty().withMessage('Academic year name is required'),
  body('start_date').isISO8601().withMessage('Valid start date is required'),
  body('end_date').isISO8601().withMessage('Valid end date is required'),
  body('is_current').optional().isBoolean(),
  validate
], adminController.createAcademicYear);

router.put('/academic-years/:id', [
  authenticate(),
  requireSuperAdmin(),
  param('id').isUUID().withMessage('Invalid academic year ID'),
  body('name').optional().notEmpty().withMessage('Name cannot be empty'),
  body('start_date').optional().isISO8601().withMessage('Valid start date is required'),
  body('end_date').optional().isISO8601().withMessage('Valid end date is required'),
  body('is_current').optional().isBoolean(),
  body('is_active').optional().isBoolean(),
  validate
], adminController.updateAcademicYear);

router.delete('/academic-years/:id', [
  authenticate(),
  requireSuperAdmin(),
  param('id').isUUID().withMessage('Invalid academic year ID'),
  validate
], adminController.deleteAcademicYear);

// Semesters
router.get('/semesters', [
  authenticate(),
  requireAdmin(),
  query('academic_year_id').optional().isUUID(),
  validate
], adminController.getAllSemesters);

router.post('/semesters', [
  authenticate(),
  requireSuperAdmin(),
  body('academic_year_id').isUUID().withMessage('Valid academic year ID required'),
  body('name').notEmpty().withMessage('Semester name is required'),
  body('start_date').isISO8601().withMessage('Valid start date is required'),
  body('end_date').isISO8601().withMessage('Valid end date is required'),
  body('is_current').optional().isBoolean(),
  validate
], adminController.createSemester);

router.put('/semesters/:id', [
  authenticate(),
  requireSuperAdmin(),
  param('id').isUUID().withMessage('Invalid semester ID'),
  body('name').optional().notEmpty().withMessage('Name cannot be empty'),
  body('start_date').optional().isISO8601().withMessage('Valid start date is required'),
  body('end_date').optional().isISO8601().withMessage('Valid end date is required'),
  body('is_current').optional().isBoolean(),
  body('is_active').optional().isBoolean(),
  validate
], adminController.updateSemester);

router.delete('/semesters/:id', [
  authenticate(),
  requireSuperAdmin(),
  param('id').isUUID().withMessage('Invalid semester ID'),
  validate
], adminController.deleteSemester);

// System settings
router.get('/settings', [
  authenticate(),
  requireAdmin(),
  validate
], adminController.getSettings);

router.put('/settings', [
  authenticate(),
  requireSuperAdmin(),
  validate
], adminController.updateSettings);

// Assessment sheet approval workflow
router.get('/assessment-sheets', [
  authenticate(),
  requireAdmin(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('status').optional().isIn(['draft', 'submitted', 'approved', 'rejected']),
  query('class_id').optional().isUUID(),
  query('subject_id').optional().isUUID(),
  validate
], adminController.getAssessmentSheets);

router.put('/assessment-sheets/:id/approve', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid assessment sheet ID'),
  validate
], adminController.approveAssessmentSheet);

router.put('/assessment-sheets/:id/reject', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid assessment sheet ID'),
  body('rejection_reason').optional().isString(),
  validate
], adminController.rejectAssessmentSheet);

export default router;
