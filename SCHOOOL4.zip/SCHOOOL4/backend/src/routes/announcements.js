import express from 'express';
import { body, query, param } from 'express-validator';
import { validate } from '../middleware/validation.js';
import { authenticate, requireAdmin, requireTeacher } from '../middleware/auth.js';
import * as announcementController from '../controllers/announcementController.js';

const router = express.Router();

router.get('/', [
  authenticate(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('target_audience').optional().isIn(['all', 'students', 'teachers', 'staff', 'admins']),
  query('priority').optional().isIn(['low', 'normal', 'high', 'urgent']),
  query('is_published').optional().isBoolean(),
  validate
], announcementController.getAllAnnouncements);

router.get('/my-announcements', [
  authenticate(),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  validate
], announcementController.getMyAnnouncements);

router.get('/:id', [
  authenticate(),
  param('id').isUUID().withMessage('Invalid announcement ID'),
  validate
], announcementController.getAnnouncementById);

router.post('/', [
  authenticate(),
  requireTeacher(),
  body('title').notEmpty().withMessage('Title is required'),
  body('content').notEmpty().withMessage('Content is required'),
  body('target_audience').optional().isIn(['all', 'students', 'teachers', 'staff', 'admins']),
  body('priority').optional().isIn(['low', 'normal', 'high', 'urgent']),
  body('expires_at').optional().isISO8601().withMessage('Valid expiration date required'),
  body('is_published').optional().isBoolean(),
  validate
], announcementController.createAnnouncement);

router.put('/:id', [
  authenticate(),
  requireTeacher(),
  param('id').isUUID().withMessage('Invalid announcement ID'),
  body('title').optional().notEmpty().withMessage('Title cannot be empty'),
  body('content').optional().notEmpty().withMessage('Content cannot be empty'),
  body('target_audience').optional().isIn(['all', 'students', 'teachers', 'staff', 'admins']),
  body('priority').optional().isIn(['low', 'normal', 'high', 'urgent']),
  body('expires_at').optional().isISO8601().withMessage('Valid expiration date required'),
  body('is_published').optional().isBoolean(),
  validate
], announcementController.updateAnnouncement);

router.delete('/:id', [
  authenticate(),
  requireAdmin(),
  param('id').isUUID().withMessage('Invalid announcement ID'),
  validate
], announcementController.deleteAnnouncement);

export default router;