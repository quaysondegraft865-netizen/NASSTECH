import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

export { AppError, asyncHandler } from '../middleware/errorHandler.js';

const JWT_SECRET = process.env.JWT_SECRET || 'default-secret-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'default-refresh-secret';
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

export function generateId() {
  return uuidv4();
}

export async function hashPassword(password) {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}

export async function verifyPassword(password, hash) {
  return await bcrypt.compare(password, hash);
}

export function generateAccessToken(user) {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
      userType: user.userType || user.role
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

export function generateRefreshToken(user) {
  return jwt.sign(
    { id: user.id, type: 'refresh' },
    JWT_REFRESH_SECRET,
    { expiresIn: JWT_REFRESH_EXPIRES_IN }
  );
}

export function verifyAccessToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

export function verifyRefreshToken(token) {
  try {
    return jwt.verify(token, JWT_REFRESH_SECRET);
  } catch (error) {
    return null;
  }
}

export function decodeToken(token) {
  try {
    return jwt.decode(token);
  } catch {
    return null;
  }
}

export function extractTokenFromHeader(authHeader) {
  if (!authHeader) return null;
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') return null;
  return parts[1];
}

export function sanitizeUser(user) {
  const { password_hash, ...safeUser } = user;
  return safeUser;
}

export function formatDate(date = new Date()) {
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

export function formatDateOnly(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

export function calculateGrade(totalScore) {
  if (totalScore >= 80) return { grade: 'A', gradePoint: 4.0 };
  if (totalScore >= 70) return { grade: 'B+', gradePoint: 3.5 };
  if (totalScore >= 60) return { grade: 'B', gradePoint: 3.0 };
  if (totalScore >= 50) return { grade: 'C', gradePoint: 2.0 };
  if (totalScore >= 40) return { grade: 'D', gradePoint: 1.0 };
  return { grade: 'F', gradePoint: 0.0 };
}

export function calculateTotalAndGrade(ca, exam, portfolio = 0, groupProject = 0, supervised = 0) {
  const total = (ca || 0) + (exam || 0) + (portfolio || 0) + (groupProject || 0) + (supervised || 0);
  const gradeInfo = calculateGrade(total);
  return { total, ...gradeInfo };
}

export function paginate(page = 1, limit = 20) {
  const offset = (Math.max(1, page) - 1) * Math.min(100, Math.max(1, limit));
  return { limit: Math.min(100, Math.max(1, limit)), offset };
}

export function buildWhereClause(filters, allowedFields) {
  const conditions = [];
  const params = [];

  for (const [key, value] of Object.entries(filters)) {
    if (allowedFields.includes(key) && value !== undefined && value !== '') {
      if (typeof value === 'string' && value.includes('%')) {
        conditions.push(`${key} LIKE ?`);
        params.push(value);
      } else {
        conditions.push(`${key} = ?`);
        params.push(value);
      }
    }
  }

  return {
    where: conditions.length ? `WHERE ${conditions.join(' AND ')}` : '',
    params
  };
}

export function buildOrderBy(sortBy, sortOrder, allowedFields, defaultField = 'created_at') {
  const field = allowedFields.includes(sortBy) ? sortBy : defaultField;
  const order = sortOrder?.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
  return `ORDER BY ${field} ${order}`;
}