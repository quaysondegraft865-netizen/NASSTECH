import db from '../config/database.js';
import { initializeDatabase } from '../models/schema.js';
import { generateId, hashPassword, formatDate, calculateGrade } from '../utils/helpers.js';

const DEMO_PASSWORD = process.env.SEED_PASSWORD || 'password123';

async function seed() {
  initializeDatabase();
  console.log('Seeding database...');

  const now = formatDate();

  // ---- Academic Year & Semesters ----
  let yearId = db.prepare("SELECT id FROM academic_years WHERE name = '2025/2026'").get();
  if (!yearId) {
    yearId = generateId();
    db.prepare(`
      INSERT INTO academic_years (id, name, start_date, end_date, is_current, is_active, created_at)
      VALUES (?, '2025/2026', '2025-09-01', '2026-07-31', 1, 1, ?)
    `).run(yearId, now);
    console.log('Created academic year 2025/2026');
  } else {
    yearId = yearId.id;
    db.prepare('UPDATE academic_years SET is_current = 1 WHERE id = ?').run(yearId);
  }

  const semesterNames = [
    { name: 'First Semester', start: '2025-09-01', end: '2025-12-19' },
    { name: 'Second Semester', start: '2026-01-12', end: '2026-04-03' },
    { name: 'Third Semester', start: '2026-04-20', end: '2026-07-31' }
  ];

  const semesterIds = [];
  for (const sem of semesterNames) {
    let semId = db.prepare('SELECT id FROM semesters WHERE academic_year_id = ? AND name = ?').get(yearId, sem.name);
    if (!semId) {
      semId = generateId();
      db.prepare(`
        INSERT INTO semesters (id, academic_year_id, name, start_date, end_date, is_current, is_active, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?)
      `).run(semId, yearId, sem.name, sem.start, sem.end, sem.name === 'First Semester' ? 1 : 0, now);
    } else {
      semId = semId.id;
    }
    semesterIds.push(semId);
  }
  console.log('Created semesters');

  // ---- Users: Super Admin & Staff Admin ----
  const admins = [
    { email: 'superadmin@nas.edu.gh', role: 'super_admin', full_name: 'Super Administrator', id: 'SUPER001' },
    { email: 'admin@nas.edu.gh', role: 'staff', full_name: 'School Administrator', id: 'ADM001' }
  ];

  const passwordHash = await hashPassword(DEMO_PASSWORD);

  for (const admin of admins) {
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(admin.email);
    if (existing) continue;

    const userId = generateId();
    db.prepare(`
      INSERT INTO users (id, email, password_hash, role, full_name, phone, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(userId, admin.email, passwordHash, admin.role, admin.full_name, null, now, now);
    console.log(`Created ${admin.role} user: ${admin.email} (password: ${DEMO_PASSWORD})`);
  }

  // ---- Subjects ----
  const subjects = [
    { code: 'AGR101', name: 'Agricultural Science', department: 'Agriculture', credits: 4 },
    { code: 'AGR102', name: 'Crop Production', department: 'Agriculture', credits: 3 },
    { code: 'AGR103', name: 'Animal Husbandry', department: 'Agriculture', credits: 3 },
    { code: 'AGR104', name: 'Soil Science', department: 'Agriculture', credits: 3 },
    { code: 'AGR105', name: 'Agricultural Economics', department: 'Agriculture', credits: 3 },
    { code: 'ENG101', name: 'English Language', department: 'Languages', credits: 3 },
    { code: 'MTH101', name: 'Mathematics', department: 'Sciences', credits: 4 },
    { code: 'SCI101', name: 'Integrated Science', department: 'Sciences', credits: 3 },
    { code: 'ICT101', name: 'Information Technology', department: 'Technology', credits: 3 },
    { code: 'BST101', name: 'Business Studies', department: 'Business', credits: 3 }
  ];

  const subjectIds = {};
  for (const sub of subjects) {
    let subId = db.prepare('SELECT id FROM subjects WHERE code = ?').get(sub.code);
    if (!subId) {
      subId = generateId();
      db.prepare(`
        INSERT INTO subjects (id, code, name, department, credits, description, is_active, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?)
      `).run(subId, sub.code, sub.name, sub.department, sub.credits, `${sub.name} course`, now);
    }
    subjectIds[sub.code] = subId.id || subId;
  }
  console.log(`Created ${Object.keys(subjectIds).length} subjects`);

  // ---- Teachers ----
  const teachers = [
    { staff_id: 'T001', name: 'Kwame Mensah', role: 'hod', department: 'Agriculture', designation: 'Head of Department', email: 'kmensah@nas.edu.gh' },
    { staff_id: 'T002', name: 'Ama Serwaa', role: 'form_master', department: 'Agriculture', designation: 'Form Master', email: 'aserwaa@nas.edu.gh' },
    { staff_id: 'T003', name: 'Kofi Boateng', role: 'teacher', department: 'Sciences', designation: 'Teacher', email: 'kboateng@nas.edu.gh' },
    { staff_id: 'T004', name: 'Efua Owusu', role: 'teacher', department: 'Languages', designation: 'Teacher', email: 'eowusu@nas.edu.gh' },
    { staff_id: 'T005', name: 'Yaw Asante', role: 'teacher', department: 'Technology', designation: 'Teacher', email: 'yasante@nas.edu.gh' },
    { staff_id: 'T006', name: 'Akosua Adjei', role: 'teacher', department: 'Business', designation: 'Teacher', email: 'aadjei@nas.edu.gh' }
  ];

  const teacherIds = {};
  for (const t of teachers) {
    let teacher = db.prepare('SELECT id, user_id FROM teachers WHERE staff_id = ?').get(t.staff_id);
    if (!teacher) {
      const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(t.email);
      let userId;
      if (existingUser) {
        userId = existingUser.id;
      } else {
        userId = generateId();
        db.prepare(`
          INSERT INTO users (id, email, password_hash, role, full_name, phone, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(userId, t.email, passwordHash, t.role, t.name, null, now, now);
      }
      const teacherId = generateId();
      db.prepare(`
        INSERT INTO teachers (id, user_id, staff_id, department, designation, qualification, specialization, hire_date, salary_grade, max_workload, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(teacherId, userId, t.staff_id, t.department, t.designation, 'M.Ed', t.department, '2020-08-01', 'S3', 24, now, now);
      teacherIds[t.staff_id] = teacherId;
    } else {
      teacherIds[t.staff_id] = teacher.id;
    }
  }
  console.log(`Created ${Object.keys(teacherIds).length} teachers (password: ${DEMO_PASSWORD})`);

  // ---- Classes ----
  const classes = [
    { name: 'Form 1A', code: 'F1A', form_level: 'Form 1', programme: 'Agricultural Science' },
    { name: 'Form 1B', code: 'F1B', form_level: 'Form 1', programme: 'Agricultural Science' },
    { name: 'Form 2A', code: 'F2A', form_level: 'Form 2', programme: 'Agricultural Science' },
    { name: 'Form 2B', code: 'F2B', form_level: 'Form 2', programme: 'General Arts' },
    { name: 'Form 3A', code: 'F3A', form_level: 'Form 3', programme: 'Agricultural Science' },
    { name: 'Form 3B', code: 'F3B', form_level: 'Form 3', programme: 'General Science' }
  ];

  const classIds = {};
  for (const cls of classes) {
    let classId = db.prepare('SELECT id FROM classes WHERE code = ? AND academic_year_id = ?').get(cls.code, yearId);
    if (!classId) {
      classId = generateId();
      const formTeacher = teacherIds['T001'];
      db.prepare(`
        INSERT INTO classes (id, name, code, form_level, programme, academic_year_id, form_teacher_id, capacity, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(classId, cls.name, cls.code, cls.form_level, cls.programme, yearId, formTeacher, 50, now, now);
    }
    classIds[cls.code] = classId.id || classId;
  }
  console.log(`Created ${Object.keys(classIds).length} classes`);

  // ---- Class Subjects & Teacher Assignments ----
  const classSubjects = {
    'F1A': ['AGR101', 'AGR102', 'ENG101', 'MTH101', 'SCI101', 'ICT101'],
    'F1B': ['AGR101', 'AGR103', 'ENG101', 'MTH101', 'SCI101', 'BST101'],
    'F2A': ['AGR101', 'AGR102', 'AGR104', 'ENG101', 'MTH101', 'ICT101'],
    'F2B': ['AGR105', 'ENG101', 'MTH101', 'SCI101', 'BST101', 'ICT101'],
    'F3A': ['AGR101', 'AGR102', 'AGR103', 'AGR105', 'ENG101', 'MTH101'],
    'F3B': ['AGR101', 'AGR104', 'ENG101', 'MTH101', 'SCI101', 'BST101']
  };

  const assignmentMap = {
    'AGR101': 'T001', 'AGR102': 'T001', 'AGR103': 'T002', 'AGR104': 'T002',
    'AGR105': 'T002', 'ENG101': 'T004', 'MTH101': 'T003', 'SCI101': 'T003',
    'ICT101': 'T005', 'BST101': 'T006'
  };

  for (const [classCode, subjectCodes] of Object.entries(classSubjects)) {
    for (const code of subjectCodes) {
      const subjectId = subjectIds[code];
      const classId = classIds[classCode];

      let csId = db.prepare(`
        SELECT id FROM class_subjects WHERE class_id = ? AND subject_id = ? AND academic_year_id = ?
      `).get(classId, subjectId, yearId);

      if (!csId) {
        csId = generateId();
        db.prepare(`
          INSERT INTO class_subjects (id, class_id, subject_id, periods_per_week, academic_year_id, created_at)
          VALUES (?, ?, ?, 4, ?, ?)
        `).run(csId, classId, subjectId, yearId, now);
      }

      const teacherStaffId = assignmentMap[code];
      const teacherId = teacherIds[teacherStaffId];

      let taId = db.prepare(`
        SELECT id FROM teacher_assignments
        WHERE teacher_id = ? AND class_id = ? AND subject_id = ? AND academic_year_id = ?
      `).get(teacherId, classId, subjectId, yearId);

      if (!taId) {
        taId = generateId();
        db.prepare(`
          INSERT INTO teacher_assignments (id, teacher_id, class_id, subject_id, academic_year_id, periods_per_week, status, assigned_by, assigned_at)
          VALUES (?, ?, ?, ?, ?, 4, 'active', ?, ?)
        `).run(taId, teacherId, classId, subjectId, yearId, null, now);
      }
    }
  }
  console.log('Created class subjects and teacher assignments');

  // ---- Students ----
  const firstNames = ['Kwame', 'Ama', 'Kofi', 'Efua', 'Yaw', 'Akosua', 'Kwaku', 'Adwoa', 'Kojo', 'Abena', 'Kwasi', 'Yaa', 'Nana', 'Serwaa', 'Osei', 'Maame', 'Kwabena', 'Afua', 'Yenwo', 'Korkor'];
  const lastNames = ['Mensah', 'Osei', 'Boateng', 'Owusu', 'Asante', 'Adjei', 'Quayson', 'De-Graft', 'Anokye', 'Bonsu', 'Dankwa', 'Eku', 'Fianoo', 'Gyamfi', 'Hagan', 'Inkoom', 'Jantuah', 'Kumah', 'Laryea', 'Mends'];
  const programmes = ['Agricultural Science', 'Agricultural Science', 'General Arts', 'General Science'];
  const levels = ['Form 1', 'Form 2', 'Form 3'];

  const studentCount = db.prepare('SELECT COUNT(*) as count FROM students').get().count;
  const toCreate = Math.max(0, 60 - studentCount);

  for (let i = 1; i <= toCreate; i++) {
    const studentNo = String(studentCount + i).padStart(4, '0');
    const studentIdCode = `NAS${studentNo}`;
    const firstName = firstNames[i % firstNames.length];
    const lastName = lastNames[(i * 7) % lastNames.length];
    const fullName = `${firstName} ${lastName}`;
    const email = `${firstName.toLowerCase()}.${lastName.toLowerCase().replace('-', '')}${studentNo}@student.nas.edu.gh`;
    const programme = programmes[i % programmes.length];
    const level = levels[i % levels.length];
    const classCode = level === 'Form 1' ? (i % 2 ? 'F1A' : 'F1B') : level === 'Form 2' ? (i % 2 ? 'F2A' : 'F2B') : (i % 2 ? 'F3A' : 'F3B');
    const gender = i % 2 ? 'male' : 'female';
    const admissionYear = String(2023 + (levels.indexOf(level)));

    const existing = db.prepare('SELECT id FROM students WHERE student_id = ?').get(studentIdCode);
    if (existing) continue;

    const userId = generateId();
    const studentDbId = generateId();

    db.exec('BEGIN TRANSACTION');
    try {
      db.prepare(`
        INSERT INTO users (id, email, password_hash, role, full_name, phone, created_at, updated_at)
        VALUES (?, ?, ?, 'student', ?, ?, ?, ?)
      `).run(userId, email, passwordHash, fullName, null, now, now);

      db.prepare(`
        INSERT INTO students (id, user_id, student_id, programme, level, semester, admission_year,
          date_of_birth, gender, address, guardian_name, guardian_phone, guardian_email, department, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'First', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(studentDbId, userId, studentIdCode, programme, level, admissionYear,
        '2008-01-01', gender, 'Nkroful, Western Region', `${lastName} Family`, '0540000000', null, programme, now, now);

      db.prepare(`
        INSERT INTO enrollments (id, student_id, class_id, academic_year_id, enrolled_at, status)
        VALUES (?, ?, ?, ?, ?, 'active')
      `).run(generateId(), studentDbId, classIds[classCode], yearId, now);

      db.exec('COMMIT');
    } catch (error) {
      db.exec('ROLLBACK');
      console.error(`Failed to create student ${studentIdCode}:`, error.message);
    }
  }
  console.log(`Students seeded (total: ${db.prepare('SELECT COUNT(*) as count FROM students').get().count})`);

  // ---- Fee Structures ----
  const feeStructures = [
    { name: 'Tuition Fee', amount: 1200, is_mandatory: 1 },
    { name: 'Accommodation Fee', amount: 800, is_mandatory: 0 },
    { name: 'Feeding Fee', amount: 1500, is_mandatory: 1 },
    { name: 'Textbook Levy', amount: 250, is_mandatory: 1 },
    { name: 'Exam Fee', amount: 150, is_mandatory: 1 }
  ];

  for (const fee of feeStructures) {
    const existing = db.prepare(`
      SELECT id FROM fee_structure WHERE name = ? AND academic_year_id = ?
    `).get(fee.name, yearId);

    if (existing) continue;

    const feeId = generateId();
    db.prepare(`
      INSERT INTO fee_structure (id, name, description, amount, class_level, programme, academic_year_id, is_mandatory, due_date, created_at)
      VALUES (?, ?, ?, ?, NULL, NULL, ?, ?, ?, ?)
    `).run(feeId, fee.name, `${fee.name} for 2025/2026 academic year`, fee.amount, yearId, fee.is_mandatory, '2025-10-31', now);
  }
  console.log('Created fee structures');

  // ---- System Settings ----
  const settings = {
    school_name: 'Nkroful Agricultural Senior High School',
    school_short_name: 'NAS',
    school_motto: 'Knowledge Through Agriculture',
    school_type: 'Senior High School',
    region: 'Western Region',
    district: 'Nkroful',
    contact_email: 'info@nas.edu.gh',
    contact_phone: '+233 54 000 0000',
    academic_term: 'First Semester'
  };

  for (const [key, value] of Object.entries(settings)) {
    db.prepare(`
      INSERT INTO system_settings (key, value, updated_at)
      VALUES (?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    `).run(key, value, now);
  }
  console.log('Updated system settings');

  console.log('\nSeed completed successfully!');
  console.log('Demo credentials:');
  console.log(`  Super Admin: superadmin@nas.edu.gh / ${DEMO_PASSWORD} (2FA: 123456)`);
  console.log(`  Admin:       admin@nas.edu.gh / ${DEMO_PASSWORD}`);
  console.log(`  Teacher:     T001 / ${DEMO_PASSWORD}`);
  console.log(`  Student:     NAS0001 / ${DEMO_PASSWORD}`);
}

seed().catch(error => {
  console.error('Seed failed:', error);
  process.exit(1);
});
