import db from '../config/database.js';
import {
  generateId,
  formatDate,
  asyncHandler,
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy
} from '../utils/helpers.js';

export const getAllClasses = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, search, form_level, programme, academic_year_id } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const conditions = [];
  const params = [];

  if (search) {
    conditions.push('(c.name LIKE ? OR c.code LIKE ?)');
    const term = `%${search}%`;
    params.push(term, term);
  }
  if (form_level) { conditions.push('c.form_level = ?'); params.push(form_level); }
  if (programme) { conditions.push('c.programme = ?'); params.push(programme); }
  if (academic_year_id) { conditions.push('c.academic_year_id = ?'); params.push(academic_year_id); }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['name', 'code', 'form_level', 'created_at'], 'c.name');

  const dataQuery = `
    SELECT c.*, ay.name as academic_year,
      u.full_name as form_teacher_name,
      (SELECT COUNT(*) FROM enrollments e WHERE e.class_id = c.id AND e.status = 'active') as student_count
    FROM classes c
    JOIN academic_years ay ON c.academic_year_id = ay.id
    LEFT JOIN teachers t ON c.form_teacher_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    ${whereClause}
    ${orderBy}
    LIMIT ? OFFSET ?
  `;
  const classes = db.prepare(dataQuery).all(...params, lim, offset);

  const countQuery = `
    SELECT COUNT(*) as total
    FROM classes c
    ${whereClause}
  `;
  const { total } = db.prepare(countQuery).get(...params);

  res.json({
    success: true,
    data: classes,
    pagination: {
      page: parseInt(page),
      limit: lim,
      total,
      totalPages: Math.ceil(total / lim)
    }
  });
});

export const getClassById = asyncHandler(async (req, res) => {
  const classRecord = db.prepare(`
    SELECT c.*, ay.name as academic_year,
      u.full_name as form_teacher_name, t.staff_id as form_teacher_staff_id
    FROM classes c
    JOIN academic_years ay ON c.academic_year_id = ay.id
    LEFT JOIN teachers t ON c.form_teacher_id = t.id
    LEFT JOIN users u ON t.user_id = u.id
    WHERE c.id = ?
  `).get(req.params.id);

  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  const studentCount = db.prepare(`
    SELECT COUNT(*) as count FROM enrollments
    WHERE class_id = ? AND status = 'active'
  `).get(req.params.id).count;

  res.json({ success: true, data: { ...classRecord, student_count: studentCount } });
});

export const createClass = asyncHandler(async (req, res) => {
  const { name, code, form_level, academic_year_id, programme, capacity = 50, form_teacher_id } = req.body;

  const existing = db.prepare('SELECT id FROM classes WHERE code = ?').get(code);
  if (existing) {
    throw new AppError('Class code already exists', 409, 'DUPLICATE_CODE');
  }

  const academicYear = db.prepare('SELECT id FROM academic_years WHERE id = ?').get(academic_year_id);
  if (!academicYear) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  if (form_teacher_id) {
    const teacher = db.prepare('SELECT id FROM teachers WHERE id = ?').get(form_teacher_id);
    if (!teacher) {
      throw new AppError('Form teacher not found', 404, 'TEACHER_NOT_FOUND');
    }
  }

  const id = generateId();
  const now = formatDate();

  db.prepare(`
    INSERT INTO classes (id, name, code, form_level, programme, academic_year_id, form_teacher_id, capacity, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, name, code.toUpperCase(), form_level, programme || null, academic_year_id, form_teacher_id || null, capacity, now, now);

  const classRecord = db.prepare(`
    SELECT c.*, ay.name as academic_year
    FROM classes c
    JOIN academic_years ay ON c.academic_year_id = ay.id
    WHERE c.id = ?
  `).get(id);

  res.status(201).json({ success: true, message: 'Class created successfully', data: classRecord });
});

export const updateClass = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, code, form_level, programme, capacity, form_teacher_id } = req.body;

  const classRecord = db.prepare('SELECT * FROM classes WHERE id = ?').get(id);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  if (code && code.toUpperCase() !== classRecord.code) {
    const existing = db.prepare('SELECT id FROM classes WHERE code = ? AND id != ?').get(code.toUpperCase(), id);
    if (existing) {
      throw new AppError('Class code already exists', 409, 'DUPLICATE_CODE');
    }
  }

  if (form_teacher_id) {
    const teacher = db.prepare('SELECT id FROM teachers WHERE id = ?').get(form_teacher_id);
    if (!teacher) {
      throw new AppError('Form teacher not found', 404, 'TEACHER_NOT_FOUND');
    }
  }

  const updates = [];
  const params = [];

  if (name) { updates.push('name = ?'); params.push(name); }
  if (code) { updates.push('code = ?'); params.push(code.toUpperCase()); }
  if (form_level) { updates.push('form_level = ?'); params.push(form_level); }
  if (programme !== undefined) { updates.push('programme = ?'); params.push(programme); }
  if (capacity !== undefined) { updates.push('capacity = ?'); params.push(capacity); }
  if (form_teacher_id !== undefined) { updates.push('form_teacher_id = ?'); params.push(form_teacher_id); }

  const now = formatDate();
  if (updates.length) {
    updates.push('updated_at = ?');
    params.push(now, id);
    db.prepare(`UPDATE classes SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }

  const updated = db.prepare(`
    SELECT c.*, ay.name as academic_year
    FROM classes c
    JOIN academic_years ay ON c.academic_year_id = ay.id
    WHERE c.id = ?
  `).get(id);

  res.json({ success: true, message: 'Class updated successfully', data: updated });
});

export const deleteClass = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const classRecord = db.prepare('SELECT * FROM classes WHERE id = ?').get(id);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  db.exec('BEGIN TRANSACTION');
  try {
    db.prepare('DELETE FROM class_subjects WHERE class_id = ?').run(id);
    db.prepare('DELETE FROM teacher_assignments WHERE class_id = ?').run(id);
    db.prepare('DELETE FROM enrollments WHERE class_id = ?').run(id);
    db.prepare('DELETE FROM classes WHERE id = ?').run(id);
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  res.json({ success: true, message: 'Class deleted successfully' });
});

export const getClassStudents = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { page = 1, limit = 20 } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const classRecord = db.prepare('SELECT id FROM classes WHERE id = ?').get(id);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  const students = db.prepare(`
    SELECT s.*, u.full_name, u.email, u.phone, e.status as enrollment_status, e.enrolled_at
    FROM enrollments e
    JOIN students s ON e.student_id = s.id
    JOIN users u ON s.user_id = u.id
    WHERE e.class_id = ?
    ORDER BY u.full_name
    LIMIT ? OFFSET ?
  `).all(id, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM enrollments WHERE class_id = ?
  `).get(id).count;

  res.json({
    success: true,
    data: students,
    pagination: { page: parseInt(page), limit: lim, total, totalPages: Math.ceil(total / lim) }
  });
});

export const getClassSubjects = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { academic_year_id } = req.query;

  const classRecord = db.prepare('SELECT id FROM classes WHERE id = ?').get(id);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  let query = `
    SELECT cs.*, s.code as subject_code, s.name as subject_name, s.department, s.credits,
      ay.name as academic_year
    FROM class_subjects cs
    JOIN subjects s ON cs.subject_id = s.id
    JOIN academic_years ay ON cs.academic_year_id = ay.id
    WHERE cs.class_id = ?
  `;
  const params = [id];

  if (academic_year_id) {
    query += ' AND cs.academic_year_id = ?';
    params.push(academic_year_id);
  }

  query += ' ORDER BY s.name';

  const subjects = db.prepare(query).all(...params);
  res.json({ success: true, data: subjects });
});

export const addClassSubject = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { subject_id, academic_year_id, periods_per_week = 4 } = req.body;

  const classRecord = db.prepare('SELECT id FROM classes WHERE id = ?').get(id);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  const subject = db.prepare('SELECT id FROM subjects WHERE id = ?').get(subject_id);
  if (!subject) {
    throw new AppError('Subject not found', 404, 'SUBJECT_NOT_FOUND');
  }

  const academicYear = db.prepare('SELECT id FROM academic_years WHERE id = ?').get(academic_year_id);
  if (!academicYear) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const existing = db.prepare(`
    SELECT id FROM class_subjects
    WHERE class_id = ? AND subject_id = ? AND academic_year_id = ?
  `).get(id, subject_id, academic_year_id);

  if (existing) {
    throw new AppError('Subject already assigned to this class', 409, 'SUBJECT_ALREADY_ASSIGNED');
  }

  const csId = generateId();
  const now = formatDate();

  db.prepare(`
    INSERT INTO class_subjects (id, class_id, subject_id, periods_per_week, academic_year_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(csId, id, subject_id, periods_per_week, academic_year_id, now);

  const record = db.prepare(`
    SELECT cs.*, s.code as subject_code, s.name as subject_name
    FROM class_subjects cs
    JOIN subjects s ON cs.subject_id = s.id
    WHERE cs.id = ?
  `).get(csId);

  res.status(201).json({ success: true, message: 'Subject added to class successfully', data: record });
});

export const removeClassSubject = asyncHandler(async (req, res) => {
  const { id, subjectId } = req.params;
  const { academic_year_id } = req.query;

  const record = db.prepare(`
    SELECT cs.* FROM class_subjects cs
    WHERE cs.class_id = ? AND cs.subject_id = ? AND cs.academic_year_id = ?
  `).get(id, subjectId, academic_year_id);

  if (!record) {
    throw new AppError('Class subject assignment not found', 404, 'CLASS_SUBJECT_NOT_FOUND');
  }

  db.prepare('DELETE FROM class_subjects WHERE id = ?').run(record.id);
  res.json({ success: true, message: 'Subject removed from class successfully' });
});

export const enrollStudents = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { student_ids, academic_year_id } = req.body;

  const classRecord = db.prepare('SELECT id, capacity FROM classes WHERE id = ?').get(id);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  const academicYear = db.prepare('SELECT id FROM academic_years WHERE id = ?').get(academic_year_id);
  if (!academicYear) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const currentCount = db.prepare(`
    SELECT COUNT(*) as count FROM enrollments
    WHERE class_id = ? AND status = 'active'
  `).get(id).count;

  if (currentCount + student_ids.length > classRecord.capacity) {
    throw new AppError(`Class capacity exceeded. ${classRecord.capacity - currentCount} spots remaining`, 400, 'CLASS_CAPACITY_EXCEEDED');
  }

  const now = formatDate();
  const results = { enrolled: 0, failed: [], errors: [] };

  db.exec('BEGIN TRANSACTION');
  try {
    for (const studentId of student_ids) {
      const student = db.prepare('SELECT id FROM students WHERE id = ?').get(studentId);
      if (!student) {
        results.failed.push({ student_id: studentId, error: 'Student not found' });
        continue;
      }

      const existing = db.prepare(`
        SELECT id FROM enrollments
        WHERE student_id = ? AND academic_year_id = ?
      `).get(studentId, academic_year_id);

      if (existing) {
        results.failed.push({ student_id: studentId, error: 'Student already enrolled for this academic year' });
        continue;
      }

      const enrollmentId = generateId();
      db.prepare(`
        INSERT INTO enrollments (id, student_id, class_id, academic_year_id, enrolled_at, status)
        VALUES (?, ?, ?, ?, ?, 'active')
      `).run(enrollmentId, studentId, id, academic_year_id, now);
      results.enrolled++;
    }
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  res.json({
    success: true,
    message: `Enrollment completed: ${results.enrolled} enrolled, ${results.failed.length} failed`,
    data: results
  });
});

export const removeStudent = asyncHandler(async (req, res) => {
  const { id, studentId } = req.params;
  const { academic_year_id } = req.query;

  const enrollment = db.prepare(`
    SELECT id FROM enrollments
    WHERE student_id = ? AND class_id = ? AND academic_year_id = ?
  `).get(studentId, id, academic_year_id);

  if (!enrollment) {
    throw new AppError('Enrollment not found', 404, 'ENROLLMENT_NOT_FOUND');
  }

  db.prepare(`
    UPDATE enrollments SET status = 'transferred' WHERE id = ?
  `).run(enrollment.id);

  res.json({ success: true, message: 'Student removed from class successfully' });
});

export default {
  getAllClasses,
  getClassById,
  createClass,
  updateClass,
  deleteClass,
  getClassStudents,
  getClassSubjects,
  addClassSubject,
  removeClassSubject,
  enrollStudents,
  removeStudent
};
