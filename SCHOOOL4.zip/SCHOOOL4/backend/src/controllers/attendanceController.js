import db from '../config/database.js';
import { 
  generateId, 
  formatDate, 
  formatDateOnly,
  asyncHandler, 
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy
} from '../utils/helpers.js';

export const getAllAttendance = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, student_id, class_id, subject_id, start_date, end_date, status } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const filters = { student_id, class_id, subject_id, status };
  Object.keys(filters).forEach(key => { if (!filters[key]) delete filters[key]; });

  const { where, params } = buildWhereClause(filters, ['student_id', 'class_id', 'subject_id', 'status']);
  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['date', 'recorded_at', 'created_at'], 'date');

  let dateWhere = '';
  if (start_date) { dateWhere += (where ? ' AND' : ' WHERE') + ' a.date >= ?'; params.push(start_date); }
  if (end_date) { dateWhere += (where || dateWhere ? ' AND' : ' WHERE') + ' a.date <= ?'; params.push(end_date); }

  const fullWhere = where + dateWhere;

  const attendance = db.prepare(`
    SELECT a.*, 
      u.full_name as student_name, s.student_id,
      c.name as class_name, sub.name as subject_name,
      ru.full_name as recorded_by_name
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN classes c ON a.class_id = c.id
    JOIN subjects sub ON a.subject_id = sub.id
    LEFT JOIN users ru ON a.recorded_by = ru.id
    ${fullWhere}
    ${orderBy}
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM attendance a ${fullWhere}
  `).get(...params).count;

  res.json({
    success: true,
    data: attendance,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});

export const getStudentAttendanceStats = asyncHandler(async (req, res) => {
  const { studentId } = req.params;
  const { start_date, end_date, subject_id } = req.query;

  let where = 'WHERE a.student_id = ?';
  const params = [studentId];

  if (start_date) { where += ' AND a.date >= ?'; params.push(start_date); }
  if (end_date) { where += ' AND a.date <= ?'; params.push(end_date); }
  if (subject_id) { where += ' AND a.subject_id = ?'; params.push(subject_id); }

  const records = db.prepare(`
    SELECT status, COUNT(*) as count
    FROM attendance a
    ${where}
    GROUP BY status
  `).all(...params);

  const stats = { present: 0, absent: 0, late: 0, excused: 0, total: 0 };
  records.forEach(r => { stats[r.status] = r.count; stats.total += r.count; });
  stats.percentage = stats.total > 0 ? parseFloat(((stats.present + stats.late) / stats.total * 100).toFixed(2)) : 0;

  res.json({ success: true, data: stats });
});

export const getClassAttendance = asyncHandler(async (req, res) => {
  const { classId } = req.params;
  const { subject_id, date } = req.query;

  let where = 'WHERE a.class_id = ?';
  const params = [classId];

  if (subject_id) { where += ' AND a.subject_id = ?'; params.push(subject_id); }
  if (date) { where += ' AND a.date = ?'; params.push(date); }

  const attendance = db.prepare(`
    SELECT a.*, 
      u.full_name as student_name, s.student_id,
      sub.name as subject_name
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN subjects sub ON a.subject_id = sub.id
    ${where}
    ORDER BY u.full_name
  `).all(...params);

  res.json({ success: true, data: attendance });
});

export const recordAttendance = asyncHandler(async (req, res) => {
  const { student_id, class_id, subject_id, academic_year_id, date, status } = req.body;

  const existing = db.prepare(`
    SELECT * FROM attendance 
    WHERE student_id = ? AND subject_id = ? AND date = ?
  `).get(student_id, subject_id, date);

  const now = formatDate();

  if (existing) {
    db.prepare(`
      UPDATE attendance SET status = ?, recorded_by = ?, recorded_at = ?
      WHERE id = ?
    `).run(status, req.user.id, now, existing.id);
    const updated = db.prepare('SELECT * FROM attendance WHERE id = ?').get(existing.id);
    res.json({ success: true, message: 'Attendance updated successfully', data: updated });
  } else {
    const id = generateId();
    db.prepare(`
      INSERT INTO attendance (id, student_id, class_id, subject_id, academic_year_id, date, status, recorded_by, recorded_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, student_id, class_id, subject_id, academic_year_id, date, status, req.user.id, now);
    const created = db.prepare('SELECT * FROM attendance WHERE id = ?').get(id);
    res.status(201).json({ success: true, message: 'Attendance recorded successfully', data: created });
  }
});

export const bulkRecordAttendance = asyncHandler(async (req, res) => {
  const { records } = req.body;
  const now = formatDate();
  const results = [];

  for (const r of records) {
    const existing = db.prepare(`
      SELECT * FROM attendance 
      WHERE student_id = ? AND subject_id = ? AND date = ?
    `).get(r.student_id, r.subject_id, r.date);

    if (existing) {
      db.prepare(`
        UPDATE attendance SET status = ?, recorded_by = ?, recorded_at = ?
        WHERE id = ?
      `).run(r.status, req.user.id, now, existing.id);
      results.push({ ...existing, status: r.status, updated: true });
    } else {
      const id = generateId();
      db.prepare(`
        INSERT INTO attendance (id, student_id, class_id, subject_id, academic_year_id, date, status, recorded_by, recorded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, r.student_id, r.class_id, r.subject_id, r.academic_year_id, r.date, r.status, req.user.id, now);
      const created = db.prepare('SELECT * FROM attendance WHERE id = ?').get(id);
      results.push({ ...created, created: true });
    }
  }

  res.json({ success: true, message: `Processed ${results.length} attendance records`, data: results });
});

export const updateAttendance = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const record = db.prepare('SELECT * FROM attendance WHERE id = ?').get(id);
  if (!record) {
    throw new AppError('Attendance record not found', 404, 'ATTENDANCE_NOT_FOUND');
  }

  const now = formatDate();
  db.prepare('UPDATE attendance SET status = ?, recorded_by = ?, recorded_at = ? WHERE id = ?')
    .run(status || record.status, req.user.id, now, id);

  const updated = db.prepare('SELECT * FROM attendance WHERE id = ?').get(id);
  res.json({ success: true, message: 'Attendance updated successfully', data: updated });
});

export const deleteAttendance = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const record = db.prepare('SELECT * FROM attendance WHERE id = ?').get(id);
  if (!record) {
    throw new AppError('Attendance record not found', 404, 'ATTENDANCE_NOT_FOUND');
  }

  db.prepare('DELETE FROM attendance WHERE id = ?').run(id);
  res.json({ success: true, message: 'Attendance record deleted successfully' });
});