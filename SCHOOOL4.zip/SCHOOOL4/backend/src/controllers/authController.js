import db from '../config/database.js';
import { 
  hashPassword, 
  verifyPassword, 
  generateAccessToken, 
  generateRefreshToken,
  sanitizeUser,
  generateId,
  formatDate,
  asyncHandler,
  AppError
} from '../utils/helpers.js';

// Student Login
export const studentLogin = asyncHandler(async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    throw new AppError('Student ID and password are required', 400, 'MISSING_CREDENTIALS');
  }

  // Find student by student_id or email
  const student = db.prepare(`
    SELECT u.*, s.student_id, s.programme, s.level, s.status as student_status
    FROM users u
    JOIN students s ON u.id = s.user_id
    WHERE (s.student_id = ? OR u.email = ?) AND u.role = 'student' AND u.is_active = 1
  `).get(username, username);

  if (!student) {
    throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
  }

  const isValid = await verifyPassword(password, student.password_hash);
  if (!isValid) {
    throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
  }

  // Update last login
  db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(formatDate(), student.id);

  const accessToken = generateAccessToken(student);
  const refreshToken = generateRefreshToken(student);

  res.json({
    success: true,
    message: 'Login successful',
    data: {
      user: sanitizeUser(student),
      accessToken,
      refreshToken
    }
  });
});

// Teacher Login
export const teacherLogin = asyncHandler(async (req, res) => {
  const { staffId, password, role: selectedRole } = req.body;
  
  if (!staffId || !password) {
    throw new AppError('Staff ID and password are required', 400, 'MISSING_CREDENTIALS');
  }

  const teacher = db.prepare(`
    SELECT u.*, t.staff_id, t.department, t.designation, t.max_workload
    FROM users u
    JOIN teachers t ON u.id = t.user_id
    WHERE t.staff_id = ? AND u.role IN ('teacher', 'form_master', 'hod') AND u.is_active = 1
  `).get(staffId);

  if (!teacher) {
    throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
  }

  // If specific role selected, verify it matches
  if (selectedRole && teacher.role !== selectedRole) {
    throw new AppError('Invalid role for this account', 401, 'INVALID_ROLE');
  }

  const isValid = await verifyPassword(password, teacher.password_hash);
  if (!isValid) {
    throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
  }

  db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(formatDate(), teacher.id);

  const accessToken = generateAccessToken(teacher);
  const refreshToken = generateRefreshToken(teacher);

  res.json({
    success: true,
    message: 'Login successful',
    data: {
      user: sanitizeUser(teacher),
      accessToken,
      refreshToken
    }
  });
});

// Super Admin Login
export const adminLogin = asyncHandler(async (req, res) => {
  const { adminId, password, otp } = req.body;
  
  if (!adminId || !password || !otp) {
    throw new AppError('Admin ID, password and 2FA code are required', 400, 'MISSING_CREDENTIALS');
  }

  if (otp.length !== 6) {
    throw new AppError('Invalid 2FA code', 400, 'INVALID_OTP');
  }

  const admin = db.prepare(`
    SELECT * FROM users WHERE email = ? AND role = 'super_admin' AND is_active = 1
  `).get(adminId);

  if (!admin) {
    throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
  }

  const isValid = await verifyPassword(password, admin.password_hash);
  if (!isValid) {
    throw new AppError('Invalid credentials', 401, 'INVALID_CREDENTIALS');
  }

  // In production, verify OTP with authenticator app
  // For now, accept a fixed OTP for demo
  const validOTP = process.env.ADMIN_DEMO_OTP || '123456';
  if (otp !== validOTP) {
    throw new AppError('Invalid 2FA code', 401, 'INVALID_OTP');
  }

  db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(formatDate(), admin.id);

  const accessToken = generateAccessToken(admin);
  const refreshToken = generateRefreshToken(admin);

  res.json({
    success: true,
    message: 'Authentication successful',
    data: {
      user: sanitizeUser(admin),
      accessToken,
      refreshToken
    }
  });
});

// Refresh Token
export const refreshToken = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  
  if (!refreshToken) {
    throw new AppError('Refresh token required', 400, 'MISSING_REFRESH_TOKEN');
  }

  const decoded = verifyRefreshToken(refreshToken);
  if (!decoded) {
    throw new AppError('Invalid or expired refresh token', 401, 'INVALID_REFRESH_TOKEN');
  }

  const user = db.prepare('SELECT id, email, role, is_active FROM users WHERE id = ?').get(decoded.id);
  
  if (!user || !user.is_active) {
    throw new AppError('User not found or deactivated', 401, 'USER_NOT_FOUND');
  }

  const newAccessToken = generateAccessToken(user);
  const newRefreshToken = generateRefreshToken(user);

  res.json({
    success: true,
    data: {
      accessToken: newAccessToken,
      refreshToken: newRefreshToken
    }
  });
});

// Get current user profile
export const getProfile = asyncHandler(async (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  
  if (!user) {
    throw new AppError('User not found', 404, 'USER_NOT_FOUND');
  }

  let profile = sanitizeUser(user);
  
  // Add role-specific data
  if (user.role === 'student') {
    const student = db.prepare('SELECT * FROM students WHERE user_id = ?').get(user.id);
    profile = { ...profile, ...student };
  } else if (['teacher', 'form_master', 'hod'].includes(user.role)) {
    const teacher = db.prepare('SELECT * FROM teachers WHERE user_id = ?').get(user.id);
    profile = { ...profile, ...teacher };
  }

  res.json({ success: true, data: profile });
});

// Change password
export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  
  if (!currentPassword || !newPassword) {
    throw new AppError('Current and new password required', 400, 'MISSING_PASSWORDS');
  }

  if (newPassword.length < 8) {
    throw new AppError('New password must be at least 8 characters', 400, 'WEAK_PASSWORD');
  }

  const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
  const isValid = await verifyPassword(currentPassword, user.password_hash);
  
  if (!isValid) {
    throw new AppError('Current password is incorrect', 401, 'INVALID_CURRENT_PASSWORD');
  }

  const newHash = await hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?')
    .run(newHash, formatDate(), req.user.id);

  res.json({ success: true, message: 'Password changed successfully' });
});

// Logout (client-side token removal, but we can blacklist if needed)
export const logout = asyncHandler(async (req, res) => {
  res.json({ success: true, message: 'Logged out successfully' });
});