import db from '../config/database.js';
import { 
  generateId, 
  formatDate, 
  asyncHandler, 
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy
} from '../utils/helpers.js';

export const getAllAnnouncements = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, target_audience, priority, is_published } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const filters = { target_audience, priority, is_published: is_published === 'true' ? 1 : is_published === 'false' ? 0 : undefined };
  Object.keys(filters).forEach(key => { if (filters[key] === undefined) delete filters[key]; });

  const { where, params } = buildWhereClause(filters, ['target_audience', 'priority', 'is_published']);
  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['published_at', 'priority', 'created_at'], 'published_at');

  const announcements = db.prepare(`
    SELECT a.*, u.full_name as author_name
    FROM announcements a
    JOIN users u ON a.author_id = u.id
    ${where}
    ${orderBy}
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM announcements ${where}
  `).get(...params).count;

  res.json({
    success: true,
    data: announcements,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});

export const getMyAnnouncements = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const userRole = req.user.role;
  let audienceFilter = '';
  if (userRole === 'student') audienceFilter = "AND (a.target_audience = 'all' OR a.target_audience = 'students')";
  else if (['teacher', 'form_master', 'hod'].includes(userRole)) audienceFilter = "AND (a.target_audience = 'all' OR a.target_audience = 'teachers')";
  else if (['staff', 'super_admin'].includes(userRole)) audienceFilter = "AND (a.target_audience = 'all' OR a.target_audience = 'staff' OR a.target_audience = 'admins')";

  const now = formatDate();
  const announcements = db.prepare(`
    SELECT a.*, u.full_name as author_name
    FROM announcements a
    JOIN users u ON a.author_id = u.id
    WHERE a.is_published = 1 
    AND (a.expires_at IS NULL OR a.expires_at > ?)
    ${audienceFilter}
    ORDER BY a.published_at DESC
    LIMIT ? OFFSET ?
  `).all(now, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM announcements a
    WHERE a.is_published = 1 
    AND (a.expires_at IS NULL OR a.expires_at > ?)
    ${audienceFilter}
  `).get(now).count;

  res.json({
    success: true,
    data: announcements,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});

export const getAnnouncementById = asyncHandler(async (req, res) => {
  const announcement = db.prepare(`
    SELECT a.*, u.full_name as author_name
    FROM announcements a
    JOIN users u ON a.author_id = u.id
    WHERE a.id = ?
  `).get(req.params.id);

  if (!announcement) {
    throw new AppError('Announcement not found', 404, 'ANNOUNCEMENT_NOT_FOUND');
  }

  res.json({ success: true, data: announcement });
});

export const createAnnouncement = asyncHandler(async (req, res) => {
  const { title, content, target_audience = 'all', priority = 'normal', expires_at, is_published = true } = req.body;

  const id = generateId();
  const now = formatDate();

  db.prepare(`
    INSERT INTO announcements (id, title, content, target_audience, priority, author_id, expires_at, is_published, published_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, title, content, target_audience, priority, req.user.id, expires_at, is_published ? 1 : 0, is_published ? now : null, now);

  const announcement = db.prepare('SELECT * FROM announcements WHERE id = ?').get(id);
  res.status(201).json({ success: true, message: 'Announcement created successfully', data: announcement });
});

export const updateAnnouncement = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { title, content, target_audience, priority, expires_at, is_published } = req.body;

  const announcement = db.prepare('SELECT * FROM announcements WHERE id = ?').get(id);
  if (!announcement) {
    throw new AppError('Announcement not found', 404, 'ANNOUNCEMENT_NOT_FOUND');
  }

  if (announcement.author_id !== req.user.id && req.user.role !== 'super_admin') {
    throw new AppError('Not authorized to update this announcement', 403, 'FORBIDDEN');
  }

  const updates = [];
  const params = [];

  if (title) { updates.push('title = ?'); params.push(title); }
  if (content) { updates.push('content = ?'); params.push(content); }
  if (target_audience) { updates.push('target_audience = ?'); params.push(target_audience); }
  if (priority) { updates.push('priority = ?'); params.push(priority); }
  if (expires_at !== undefined) { updates.push('expires_at = ?'); params.push(expires_at); }
  if (is_published !== undefined) { 
    updates.push('is_published = ?'); 
    params.push(is_published ? 1 : 0);
    if (is_published && !announcement.published_at) {
      updates.push('published_at = ?');
      params.push(formatDate());
    }
  }

  if (updates.length) {
    params.push(id);
    db.prepare(`UPDATE announcements SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }

  const updated = db.prepare('SELECT * FROM announcements WHERE id = ?').get(id);
  res.json({ success: true, message: 'Announcement updated successfully', data: updated });
});

export const deleteAnnouncement = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const announcement = db.prepare('SELECT * FROM announcements WHERE id = ?').get(id);
  if (!announcement) {
    throw new AppError('Announcement not found', 404, 'ANNOUNCEMENT_NOT_FOUND');
  }

  db.prepare('DELETE FROM announcements WHERE id = ?').run(id);
  res.json({ success: true, message: 'Announcement deleted successfully' });
});