import db from '../config/database.js';
import { 
  generateId, 
  formatDate, 
  asyncHandler, 
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy,
  calculateTotalAndGrade
} from '../utils/helpers.js';

export const getAllGrades = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, student_id, subject_id, class_id, academic_year_id, semester_id } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const filters = { student_id, subject_id, class_id, academic_year_id, semester_id };
  Object.keys(filters).forEach(key => {
    if (!filters[key]) delete filters[key];
  });

  const { where, params } = buildWhereClause(filters, ['student_id', 'subject_id', 'class_id', 'academic_year_id', 'semester_id']);
  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['entered_at', 'total_score', 'created_at'], 'entered_at');

  const grades = db.prepare(`
    SELECT g.*, 
      u.full_name as student_name, s.student_id,
      sub.name as subject_name, sub.code as subject_code,
      c.name as class_name
    FROM grades g
    JOIN students s ON g.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN subjects sub ON g.subject_id = sub.id
    JOIN classes c ON g.class_id = c.id
    ${where}
    ${orderBy}
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM grades ${where}
  `).get(...params).count;

  res.json({
    success: true,
    data: grades,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});

export const getStudentGradeSummary = asyncHandler(async (req, res) => {
  const { studentId } = req.params;
  const { academic_year_id, semester_id } = req.query;

  let where = 'WHERE g.student_id = ?';
  const params = [studentId];

  if (academic_year_id) {
    where += ' AND g.academic_year_id = ?';
    params.push(academic_year_id);
  }
  if (semester_id) {
    where += ' AND g.semester_id = ?';
    params.push(semester_id);
  }

  const grades = db.prepare(`
    SELECT g.*, 
      sub.name as subject_name, sub.code as subject_code, sub.credits,
      c.name as class_name, ay.name as academic_year, sem.name as semester
    FROM grades g
    JOIN subjects sub ON g.subject_id = sub.id
    JOIN classes c ON g.class_id = c.id
    JOIN academic_years ay ON g.academic_year_id = ay.id
    JOIN semesters sem ON g.semester_id = sem.id
    ${where}
    ORDER BY sub.name
  `).all(...params);

  const summary = grades.map(g => {
    const { total, grade, gradePoint } = calculateTotalAndGrade(g.ca_score, g.exam_score);
    return { ...g, total, grade, gradePoint };
  });

  const avgGradePoint = summary.length 
    ? summary.reduce((sum, g) => sum + (g.gradePoint * g.credits), 0) / summary.reduce((sum, g) => sum + g.credits, 0)
    : 0;

  res.json({ 
    success: true, 
    data: { grades: summary, gpa: parseFloat(avgGradePoint.toFixed(2)), totalSubjects: summary.length } 
  });
});

export const getClassGrades = asyncHandler(async (req, res) => {
  const { classId } = req.params;
  const { subject_id, academic_year_id, semester_id } = req.query;

  let where = 'WHERE g.class_id = ?';
  const params = [classId];

  if (subject_id) { where += ' AND g.subject_id = ?'; params.push(subject_id); }
  if (academic_year_id) { where += ' AND g.academic_year_id = ?'; params.push(academic_year_id); }
  if (semester_id) { where += ' AND g.semester_id = ?'; params.push(semester_id); }

  const grades = db.prepare(`
    SELECT g.*, 
      u.full_name as student_name, s.student_id,
      sub.name as subject_name, sub.code as subject_code
    FROM grades g
    JOIN students s ON g.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN subjects sub ON g.subject_id = sub.id
    ${where}
    ORDER BY u.full_name
  `).all(...params);

  const processed = grades.map(g => ({ ...g, ...calculateTotalAndGrade(g.ca_score, g.exam_score) }));
  res.json({ success: true, data: processed });
});

export const getGradeById = asyncHandler(async (req, res) => {
  const grade = db.prepare(`
    SELECT g.*, 
      u.full_name as student_name, s.student_id,
      sub.name as subject_name, sub.code as subject_code,
      c.name as class_name
    FROM grades g
    JOIN students s ON g.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN subjects sub ON g.subject_id = sub.id
    JOIN classes c ON g.class_id = c.id
    WHERE g.id = ?
  `).get(req.params.id);

  if (!grade) {
    throw new AppError('Grade not found', 404, 'GRADE_NOT_FOUND');
  }

  res.json({ success: true, data: { ...grade, ...calculateTotalAndGrade(grade.ca_score, grade.exam_score) } });
});

export const createOrUpdateGrade = asyncHandler(async (req, res) => {
  const { student_id, subject_id, class_id, academic_year_id, semester_id, ca_score = 0, exam_score = 0, remarks } = req.body;

  const existing = db.prepare(`
    SELECT * FROM grades 
    WHERE student_id = ? AND subject_id = ? AND semester_id = ?
  `).get(student_id, subject_id, semester_id);

  const { total, grade, gradePoint } = calculateTotalAndGrade(ca_score, exam_score);
  const now = formatDate();

  if (existing) {
    db.prepare(`
      UPDATE grades SET ca_score = ?, exam_score = ?, total_score = ?, grade = ?, grade_point = ?, 
        remarks = ?, entered_by = ?, updated_at = ?
      WHERE id = ?
    `).run(ca_score, exam_score, total, grade, gradePoint, remarks, req.user.id, now, existing.id);

    const updated = db.prepare('SELECT * FROM grades WHERE id = ?').get(existing.id);
    res.json({ success: true, message: 'Grade updated successfully', data: updated });
  } else {
    const id = generateId();
    db.prepare(`
      INSERT INTO grades (id, student_id, subject_id, class_id, academic_year_id, semester_id, 
        ca_score, exam_score, total_score, grade, grade_point, remarks, entered_by, entered_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, student_id, subject_id, class_id, academic_year_id, semester_id, ca_score, exam_score, total, grade, gradePoint, remarks, req.user.id, now, now);

    const created = db.prepare('SELECT * FROM grades WHERE id = ?').get(id);
    res.status(201).json({ success: true, message: 'Grade created successfully', data: created });
  }
});

export const bulkCreateGrades = asyncHandler(async (req, res) => {
  const { grades } = req.body;
  const now = formatDate();
  const results = [];

  for (const g of grades) {
    const { total, grade, gradePoint } = calculateTotalAndGrade(g.ca_score || 0, g.exam_score || 0);

    const existing = db.prepare(`
      SELECT * FROM grades 
      WHERE student_id = ? AND subject_id = ? AND semester_id = ?
    `).get(g.student_id, g.subject_id, g.semester_id);

    if (existing) {
      db.prepare(`
        UPDATE grades SET ca_score = ?, exam_score = ?, total_score = ?, grade = ?, grade_point = ?, 
          remarks = ?, entered_by = ?, updated_at = ?
        WHERE id = ?
      `).run(g.ca_score || 0, g.exam_score || 0, total, grade, gradePoint, g.remarks, req.user.id, now, existing.id);
      results.push({ ...existing, ...calculateTotalAndGrade(g.ca_score || 0, g.exam_score || 0), updated: true });
    } else {
      const id = generateId();
      db.prepare(`
        INSERT INTO grades (id, student_id, subject_id, class_id, academic_year_id, semester_id, 
          ca_score, exam_score, total_score, grade, grade_point, remarks, entered_by, entered_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, g.student_id, g.subject_id, g.class_id, g.academic_year_id, g.semester_id, 
        g.ca_score || 0, g.exam_score || 0, total, grade, gradePoint, g.remarks, req.user.id, now, now);
      const created = db.prepare('SELECT * FROM grades WHERE id = ?').get(id);
      results.push({ ...created, ...calculateTotalAndGrade(g.ca_score || 0, g.exam_score || 0), created: true });
    }
  }

  res.json({ success: true, message: `Processed ${results.length} grades`, data: results });
});

export const updateGrade = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { ca_score, exam_score, remarks } = req.body;

  const grade = db.prepare('SELECT * FROM grades WHERE id = ?').get(id);
  if (!grade) {
    throw new AppError('Grade not found', 404, 'GRADE_NOT_FOUND');
  }

  const newCA = ca_score !== undefined ? ca_score : grade.ca_score;
  const newExam = exam_score !== undefined ? exam_score : grade.exam_score;
  const { total, grade: letterGrade, gradePoint } = calculateTotalAndGrade(newCA, newExam);
  const now = formatDate();

  db.prepare(`
    UPDATE grades SET ca_score = ?, exam_score = ?, total_score = ?, grade = ?, grade_point = ?, 
      remarks = ?, updated_at = ?
    WHERE id = ?
  `).run(newCA, newExam, total, letterGrade, gradePoint, remarks ?? grade.remarks, now, id);

  const updated = db.prepare('SELECT * FROM grades WHERE id = ?').get(id);
  res.json({ success: true, message: 'Grade updated successfully', data: { ...updated, ...calculateTotalAndGrade(updated.ca_score, updated.exam_score) } });
});

export const deleteGrade = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const grade = db.prepare('SELECT * FROM grades WHERE id = ?').get(id);
  if (!grade) {
    throw new AppError('Grade not found', 404, 'GRADE_NOT_FOUND');
  }

  db.prepare('DELETE FROM grades WHERE id = ?').run(id);
  res.json({ success: true, message: 'Grade deleted successfully' });
});