import db from '../config/database.js';
import {
  generateId,
  formatDate,
  asyncHandler,
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy,
  calculateTotalAndGrade
} from '../utils/helpers.js';

export const getStudentTranscript = asyncHandler(async (req, res) => {
  const { studentId } = req.params;
  const { academic_year_id } = req.query;

  const student = db.prepare(`
    SELECT s.*, u.full_name, u.email, s.student_id
    FROM students s JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
  `).get(studentId);

  if (!student) {
    throw new AppError('Student not found', 404, 'STUDENT_NOT_FOUND');
  }

  let query = `
    SELECT g.*,
      sub.name as subject_name, sub.code as subject_code, sub.credits,
      c.name as class_name, c.form_level,
      ay.name as academic_year, sem.name as semester,
      g.ca_score, g.exam_score
    FROM grades g
    JOIN subjects sub ON g.subject_id = sub.id
    JOIN classes c ON g.class_id = c.id
    JOIN academic_years ay ON g.academic_year_id = ay.id
    JOIN semesters sem ON g.semester_id = sem.id
    WHERE g.student_id = ?
  `;
  const params = [studentId];

  if (academic_year_id) {
    query += ' AND g.academic_year_id = ?';
    params.push(academic_year_id);
  }

  query += ' ORDER BY ay.start_date DESC, sem.start_date, sub.name';

  const grades = db.prepare(query).all(...params);
  const processed = grades.map(g => ({ ...g, ...calculateTotalAndGrade(g.ca_score, g.exam_score) }));

  res.json({
    success: true,
    data: { student, grades: processed, totalSubjects: processed.length }
  });
});

export const getStudentReportCard = asyncHandler(async (req, res) => {
  const { studentId } = req.params;
  const { academic_year_id, semester_id } = req.query;

  const student = db.prepare(`
    SELECT s.*, u.full_name, u.email, s.student_id
    FROM students s JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
  `).get(studentId);

  if (!student) {
    throw new AppError('Student not found', 404, 'STUDENT_NOT_FOUND');
  }

  const academicYear = db.prepare('SELECT name FROM academic_years WHERE id = ?').get(academic_year_id);
  if (!academicYear) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const semester = db.prepare('SELECT name FROM semesters WHERE id = ?').get(semester_id);
  if (!semester) {
    throw new AppError('Semester not found', 404, 'SEMESTER_NOT_FOUND');
  }

  const grades = db.prepare(`
    SELECT g.*,
      sub.name as subject_name, sub.code as subject_code, sub.credits,
      c.name as class_name,
      u2.full_name as teacher_name
    FROM grades g
    JOIN subjects sub ON g.subject_id = sub.id
    JOIN classes c ON g.class_id = c.id
    LEFT JOIN teacher_assignments ta ON ta.subject_id = g.subject_id AND ta.class_id = g.class_id AND ta.academic_year_id = g.academic_year_id
    LEFT JOIN teachers t ON ta.teacher_id = t.id
    LEFT JOIN users u2 ON t.user_id = u2.id
    WHERE g.student_id = ? AND g.academic_year_id = ? AND g.semester_id = ?
    ORDER BY sub.name
  `).all(studentId, academic_year_id, semester_id);

  const processed = grades.map(g => ({ ...g, ...calculateTotalAndGrade(g.ca_score, g.exam_score) }));

  const totalCredits = processed.reduce((sum, g) => sum + (g.credits || 0), 0);
  const weightedPoints = processed.reduce((sum, g) => sum + ((g.gradePoint || 0) * (g.credits || 0)), 0);
  const gpa = totalCredits > 0 ? parseFloat((weightedPoints / totalCredits).toFixed(2)) : 0;
  const avgScore = processed.length > 0
    ? parseFloat((processed.reduce((sum, g) => sum + g.total, 0) / processed.length).toFixed(2))
    : 0;

  res.json({
    success: true,
    data: {
      student,
      academic_year: academicYear.name,
      semester: semester.name,
      grades: processed,
      summary: { totalSubjects: processed.length, totalCredits, gpa, averageScore: avgScore }
    }
  });
});

export const getClassGradeSheet = asyncHandler(async (req, res) => {
  const { classId } = req.params;
  const { subject_id, academic_year_id, semester_id } = req.query;

  const classRecord = db.prepare('SELECT id, name FROM classes WHERE id = ?').get(classId);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  const grades = db.prepare(`
    SELECT g.*,
      u.full_name as student_name, s.student_id,
      sub.name as subject_name, sub.code as subject_code
    FROM grades g
    JOIN students s ON g.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN subjects sub ON g.subject_id = sub.id
    WHERE g.class_id = ? AND g.subject_id = ? AND g.academic_year_id = ? AND g.semester_id = ?
    ORDER BY u.full_name
  `).all(classId, subject_id, academic_year_id, semester_id);

  const processed = grades.map(g => ({ ...g, ...calculateTotalAndGrade(g.ca_score, g.exam_score) }));

  const subject = db.prepare('SELECT name, code FROM subjects WHERE id = ?').get(subject_id);

  res.json({
    success: true,
    data: {
      class: classRecord,
      subject,
      grades: processed,
      statistics: {
        totalStudents: processed.length,
        averageScore: processed.length ? parseFloat((processed.reduce((sum, g) => sum + g.total, 0) / processed.length).toFixed(2)) : 0,
        highestScore: processed.length ? Math.max(...processed.map(g => g.total)) : 0,
        lowestScore: processed.length ? Math.min(...processed.map(g => g.total)) : 0
      }
    }
  });
});

export const getClassAttendanceSummary = asyncHandler(async (req, res) => {
  const { classId } = req.params;
  const { start_date, end_date, subject_id } = req.query;

  const classRecord = db.prepare('SELECT id, name FROM classes WHERE id = ?').get(classId);
  if (!classRecord) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  let where = `WHERE a.class_id = ? AND a.date >= ? AND a.date <= ?`;
  const params = [classId, start_date, end_date];

  if (subject_id) {
    where += ' AND a.subject_id = ?';
    params.push(subject_id);
  }

  const summary = db.prepare(`
    SELECT s.id as student_id, s.student_id, u.full_name as student_name,
      COUNT(*) as total_sessions,
      SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present,
      SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent,
      SUM(CASE WHEN a.status = 'late' THEN 1 ELSE 0 END) as late,
      SUM(CASE WHEN a.status = 'excused' THEN 1 ELSE 0 END) as excused
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    JOIN users u ON s.user_id = u.id
    ${where}
    GROUP BY s.id, s.student_id, u.full_name
    ORDER BY u.full_name
  `).all(...params);

  const processed = summary.map(s => ({
    ...s,
    attendance_rate: s.total_sessions > 0 ? parseFloat((((s.present + s.late) / s.total_sessions) * 100).toFixed(2)) : 0
  }));

  res.json({ success: true, data: { class: classRecord, students: processed } });
});

export const getTeacherWorkload = asyncHandler(async (req, res) => {
  const { teacherId } = req.params;
  const { academic_year_id } = req.query;

  const teacher = db.prepare(`
    SELECT t.*, u.full_name, u.email, t.staff_id
    FROM teachers t JOIN users u ON t.user_id = u.id
    WHERE t.id = ?
  `).get(teacherId);

  if (!teacher) {
    throw new AppError('Teacher not found', 404, 'TEACHER_NOT_FOUND');
  }

  let where = `WHERE ta.teacher_id = ? AND ta.status = 'active'`;
  const params = [teacherId];

  if (academic_year_id) {
    where += ' AND ta.academic_year_id = ?';
    params.push(academic_year_id);
  }

  const assignments = db.prepare(`
    SELECT ta.*, c.name as class_name, c.code as class_code,
      s.name as subject_name, s.code as subject_code,
      ay.name as academic_year
    FROM teacher_assignments ta
    JOIN classes c ON ta.class_id = c.id
    JOIN subjects s ON ta.subject_id = s.id
    JOIN academic_years ay ON ta.academic_year_id = ay.id
    ${where}
    ORDER BY ay.start_date DESC, c.name
  `).all(...params);

  const totalPeriods = assignments.reduce((sum, a) => sum + (a.periods_per_week || 0), 0);
  const utilization = teacher.max_workload > 0 ? parseFloat(((totalPeriods / teacher.max_workload) * 100).toFixed(2)) : 0;

  res.json({
    success: true,
    data: {
      teacher,
      assignments,
      summary: {
        totalAssignments: assignments.length,
        totalPeriodsPerWeek: totalPeriods,
        maxWorkload: teacher.max_workload,
        utilizationPercent: utilization
      }
    }
  });
});

export const getFeeCollectionReport = asyncHandler(async (req, res) => {
  const { academic_year_id, start_date, end_date } = req.query;

  const conditions = [];
  const params = [];

  if (academic_year_id) {
    conditions.push('ay.id = ?');
    params.push(academic_year_id);
  }
  if (start_date) {
    conditions.push('p.paid_at >= ?');
    params.push(start_date);
  }
  if (end_date) {
    conditions.push('p.paid_at <= ?');
    params.push(end_date);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const summary = db.prepare(`
    SELECT
      COUNT(*) as total_payments,
      COALESCE(SUM(p.amount), 0) as total_collected,
      COUNT(DISTINCT p.student_id) as students_paid
    FROM payments p
    JOIN students s ON p.student_id = s.id
    JOIN student_fees sf ON p.student_fee_id = sf.id
    JOIN academic_years ay ON sf.academic_year_id = ay.id
    ${whereClause}
  `).get(...params);

  const byMethod = db.prepare(`
    SELECT p.payment_method, COUNT(*) as count, COALESCE(SUM(p.amount), 0) as amount
    FROM payments p
    JOIN student_fees sf ON p.student_fee_id = sf.id
    ${whereClause}
    GROUP BY p.payment_method
    ORDER BY amount DESC
  `).all(...params);

  const byMonth = db.prepare(`
    SELECT strftime('%Y-%m', p.paid_at) as month, COUNT(*) as count, COALESCE(SUM(p.amount), 0) as amount
    FROM payments p
    JOIN student_fees sf ON p.student_fee_id = sf.id
    ${whereClause}
    GROUP BY month
    ORDER BY month DESC
  `).all(...params);

  const outstanding = db.prepare(`
    SELECT COUNT(*) as count, COALESCE(SUM(sf.amount_due - sf.amount_paid), 0) as balance
    FROM student_fees sf
    WHERE sf.status IN ('pending', 'partial', 'overdue')
  `).get();

  res.json({
    success: true,
    data: {
      summary: { ...summary, outstandingBalance: outstanding.balance, outstandingCount: outstanding.count },
      byPaymentMethod: byMethod,
      byMonth
    }
  });
});

export const getEnrollmentSummary = asyncHandler(async (req, res) => {
  const { academic_year_id } = req.query;

  const yearConditions = [];
  const yearParams = [];
  if (academic_year_id) {
    yearConditions.push('ay.id = ?');
    yearParams.push(academic_year_id);
  }

  const studentConditions = ["e.status = 'active'", ...yearConditions];
  const studentWhere = `WHERE ${studentConditions.join(' AND ')}`;

  const classWhere = yearConditions.length ? `WHERE ${yearConditions.join(' AND ')}` : '';

  const totalStudents = db.prepare(`
    SELECT COUNT(DISTINCT s.id) as count
    FROM students s
    JOIN enrollments e ON s.id = e.student_id
    JOIN academic_years ay ON e.academic_year_id = ay.id
    ${studentWhere}
  `).get(...yearParams).count;

  const byClass = db.prepare(`
    SELECT c.id, c.name, c.code, c.form_level, c.programme,
      COUNT(DISTINCT e.student_id) as student_count,
      c.capacity,
      ay.name as academic_year
    FROM classes c
    JOIN academic_years ay ON c.academic_year_id = ay.id
    LEFT JOIN enrollments e ON c.id = e.class_id AND e.status = 'active'
    ${classWhere}
    GROUP BY c.id
    ORDER BY c.form_level, c.name
  `).all(...yearParams);

  const byProgramme = db.prepare(`
    SELECT st.programme, COUNT(DISTINCT st.id) as student_count
    FROM enrollments e
    JOIN students st ON e.student_id = st.id
    JOIN academic_years ay ON e.academic_year_id = ay.id
    ${studentWhere} AND st.programme IS NOT NULL
    GROUP BY st.programme
    ORDER BY student_count DESC
  `).all(...yearParams);

  const byGender = db.prepare(`
    SELECT st.gender, COUNT(DISTINCT st.id) as student_count
    FROM enrollments e
    JOIN students st ON e.student_id = st.id
    JOIN academic_years ay ON e.academic_year_id = ay.id
    ${studentWhere}
    GROUP BY st.gender
  `).all(...yearParams);

  res.json({
    success: true,
    data: {
      totalStudents,
      totalClasses: byClass.length,
      byClass,
      byProgramme,
      byGender
    }
  });
});

export const getAcademicPerformance = asyncHandler(async (req, res) => {
  const { academic_year_id, semester_id } = req.query;

  const academicYear = db.prepare('SELECT name FROM academic_years WHERE id = ?').get(academic_year_id);
  if (!academicYear) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const conditions = ['g.academic_year_id = ?'];
  const params = [academic_year_id];

  if (semester_id) {
    conditions.push('g.semester_id = ?');
    params.push(semester_id);
  }

  const whereClause = `WHERE ${conditions.join(' AND ')}`;

  const bySubject = db.prepare(`
    SELECT sub.id, sub.code, sub.name, sub.department,
      COUNT(g.id) as entries,
      COALESCE(AVG(g.total_score), 0) as average_score,
      COALESCE(MIN(g.total_score), 0) as min_score,
      COALESCE(MAX(g.total_score), 0) as max_score,
      SUM(CASE WHEN g.grade IN ('A', 'B+', 'B') THEN 1 ELSE 0 END) as distinctions,
      SUM(CASE WHEN g.grade = 'F' THEN 1 ELSE 0 END) as failures
    FROM grades g
    JOIN subjects sub ON g.subject_id = sub.id
    ${whereClause}
    GROUP BY sub.id
    ORDER BY average_score DESC
  `).all(...params);

  const byClass = db.prepare(`
    SELECT c.id, c.name, c.code, c.form_level,
      COUNT(g.id) as entries,
      COALESCE(AVG(g.total_score), 0) as average_score
    FROM grades g
    JOIN classes c ON g.class_id = c.id
    ${whereClause}
    GROUP BY c.id
    ORDER BY average_score DESC
  `).all(...params);

  const gradeDistribution = db.prepare(`
    SELECT g.grade, COUNT(*) as count
    FROM grades g
    ${whereClause}
    GROUP BY g.grade
    ORDER BY g.grade
  `).all(...params);

  const overall = db.prepare(`
    SELECT COUNT(*) as total_entries,
      COALESCE(AVG(total_score), 0) as overall_average,
      COALESCE(SUM(CASE WHEN grade = 'F' THEN 1 ELSE 0 END), 0) as total_failures
    FROM grades
    ${whereClause}
  `).get(...params);

  res.json({
    success: true,
    data: {
      academic_year: academicYear.name,
      overall: { ...overall, overall_average: parseFloat(overall.overall_average.toFixed(2)) },
      bySubject: bySubject.map(s => ({ ...s, average_score: parseFloat(s.average_score.toFixed(2)) })),
      byClass: byClass.map(c => ({ ...c, average_score: parseFloat(c.average_score.toFixed(2)) })),
      gradeDistribution
    }
  });
});

export default {
  getStudentTranscript,
  getStudentReportCard,
  getClassGradeSheet,
  getClassAttendanceSummary,
  getTeacherWorkload,
  getFeeCollectionReport,
  getEnrollmentSummary,
  getAcademicPerformance
};
