import db from '../config/database.js';
import { 
  generateId, 
  formatDate, 
  asyncHandler, 
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy
} from '../utils/helpers.js';

export const getAllSubjects = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, search, department, is_active } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const filters = {};
  if (search) filters.name = `%${search}%`;
  if (department) filters.department = department;
  if (is_active !== undefined) filters.is_active = is_active === 'true' ? 1 : 0;

  const { where, params } = buildWhereClause(filters, ['name', 'department', 'is_active']);
  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['name', 'code', 'department', 'created_at'], 'name');

  const subjects = db.prepare(`
    SELECT s.*, 
      COUNT(cs.id) as class_count
    FROM subjects s
    LEFT JOIN class_subjects cs ON s.id = cs.subject_id
    ${where}
    GROUP BY s.id
    ${orderBy}
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM subjects ${where}
  `).get(...params).count;

  res.json({
    success: true,
    data: subjects,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});

export const getSubjectById = asyncHandler(async (req, res) => {
  const subject = db.prepare('SELECT * FROM subjects WHERE id = ?').get(req.params.id);

  if (!subject) {
    throw new AppError('Subject not found', 404, 'SUBJECT_NOT_FOUND');
  }

  res.json({ success: true, data: subject });
});

export const createSubject = asyncHandler(async (req, res) => {
  const { code, name, department, credits, description } = req.body;

  const existing = db.prepare('SELECT id FROM subjects WHERE code = ?').get(code);
  if (existing) {
    throw new AppError('Subject code already exists', 409, 'DUPLICATE_CODE');
  }

  const id = generateId();
  const now = formatDate();

  db.prepare(`
    INSERT INTO subjects (id, code, name, department, credits, description, is_active, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
  `).run(id, code.toUpperCase(), name, department, credits || 3, description, now);

  const subject = db.prepare('SELECT * FROM subjects WHERE id = ?').get(id);

  res.status(201).json({ success: true, message: 'Subject created successfully', data: subject });
});

export const updateSubject = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { code, name, department, credits, description, is_active } = req.body;

  const subject = db.prepare('SELECT * FROM subjects WHERE id = ?').get(id);
  if (!subject) {
    throw new AppError('Subject not found', 404, 'SUBJECT_NOT_FOUND');
  }

  if (code && code !== subject.code) {
    const existing = db.prepare('SELECT id FROM subjects WHERE code = ? AND id != ?').get(code.toUpperCase(), id);
    if (existing) {
      throw new AppError('Subject code already exists', 409, 'DUPLICATE_CODE');
    }
  }

  const updates = [];
  const params = [];

  if (code) { updates.push('code = ?'); params.push(code.toUpperCase()); }
  if (name) { updates.push('name = ?'); params.push(name); }
  if (department !== undefined) { updates.push('department = ?'); params.push(department); }
  if (credits !== undefined) { updates.push('credits = ?'); params.push(credits); }
  if (description !== undefined) { updates.push('description = ?'); params.push(description); }
  if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }

  if (updates.length) {
    updates.push('updated_at = ?');
    params.push(formatDate());
    params.push(id);

    db.prepare(`UPDATE subjects SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }

  const updated = db.prepare('SELECT * FROM subjects WHERE id = ?').get(id);
  res.json({ success: true, message: 'Subject updated successfully', data: updated });
});

export const deleteSubject = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const subject = db.prepare('SELECT * FROM subjects WHERE id = ?').get(id);
  if (!subject) {
    throw new AppError('Subject not found', 404, 'SUBJECT_NOT_FOUND');
  }

  const inUse = db.prepare('SELECT 1 FROM class_subjects WHERE subject_id = ? LIMIT 1').get(id);
  if (inUse) {
    throw new AppError('Cannot delete subject that is assigned to classes', 400, 'SUBJECT_IN_USE');
  }

  db.prepare('DELETE FROM subjects WHERE id = ?').run(id);
  res.json({ success: true, message: 'Subject deleted successfully' });
});

export const getSubjectClasses = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { academic_year_id } = req.query;

  let query = `
    SELECT cs.*, c.name as class_name, c.code as class_code, c.form_level, ay.name as academic_year
    FROM class_subjects cs
    JOIN classes c ON cs.class_id = c.id
    JOIN academic_years ay ON cs.academic_year_id = ay.id
    WHERE cs.subject_id = ?
  `;
  const params = [id];

  if (academic_year_id) {
    query += ' AND cs.academic_year_id = ?';
    params.push(academic_year_id);
  }

  const classes = db.prepare(query).all(...params);
  res.json({ success: true, data: classes });
});