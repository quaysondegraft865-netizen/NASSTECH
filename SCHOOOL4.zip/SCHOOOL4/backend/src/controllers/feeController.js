import db from '../config/database.js';
import { 
  generateId, 
  formatDate, 
  formatDateOnly,
  asyncHandler, 
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy
} from '../utils/helpers.js';

export const getFeeStructures = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, academic_year_id, class_level, programme } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const filters = { academic_year_id, class_level, programme };
  Object.keys(filters).forEach(key => { if (!filters[key]) delete filters[key]; });

  const { where, params } = buildWhereClause(filters, ['academic_year_id', 'class_level', 'programme']);
  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['name', 'amount', 'created_at'], 'name');

  const structures = db.prepare(`
    SELECT fs.*, ay.name as academic_year
    FROM fee_structure fs
    JOIN academic_years ay ON fs.academic_year_id = ay.id
    ${where}
    ${orderBy}
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM fee_structure ${where}
  `).get(...params).count;

  res.json({
    success: true,
    data: structures,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});

export const createFeeStructure = asyncHandler(async (req, res) => {
  const { name, description, amount, class_level, programme, academic_year_id, is_mandatory, due_date } = req.body;

  const id = generateId();
  const now = formatDate();

  db.prepare(`
    INSERT INTO fee_structure (id, name, description, amount, class_level, programme, academic_year_id, is_mandatory, due_date, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, name, description, amount, class_level, programme, academic_year_id, is_mandatory ? 1 : 1, due_date, now);

  const structure = db.prepare('SELECT * FROM fee_structure WHERE id = ?').get(id);
  res.status(201).json({ success: true, message: 'Fee structure created successfully', data: structure });
});

export const updateFeeStructure = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, description, amount, class_level, programme, is_mandatory, due_date } = req.body;

  const structure = db.prepare('SELECT * FROM fee_structure WHERE id = ?').get(id);
  if (!structure) {
    throw new AppError('Fee structure not found', 404, 'FEE_STRUCTURE_NOT_FOUND');
  }

  const updates = [];
  const params = [];

  if (name) { updates.push('name = ?'); params.push(name); }
  if (description !== undefined) { updates.push('description = ?'); params.push(description); }
  if (amount !== undefined) { updates.push('amount = ?'); params.push(amount); }
  if (class_level !== undefined) { updates.push('class_level = ?'); params.push(class_level); }
  if (programme !== undefined) { updates.push('programme = ?'); params.push(programme); }
  if (is_mandatory !== undefined) { updates.push('is_mandatory = ?'); params.push(is_mandatory ? 1 : 0); }
  if (due_date !== undefined) { updates.push('due_date = ?'); params.push(due_date); }

  if (updates.length) {
    params.push(id);
    db.prepare(`UPDATE fee_structure SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }

  const updated = db.prepare('SELECT * FROM fee_structure WHERE id = ?').get(id);
  res.json({ success: true, message: 'Fee structure updated successfully', data: updated });
});

export const deleteFeeStructure = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const structure = db.prepare('SELECT * FROM fee_structure WHERE id = ?').get(id);
  if (!structure) {
    throw new AppError('Fee structure not found', 404, 'FEE_STRUCTURE_NOT_FOUND');
  }

  const assigned = db.prepare('SELECT 1 FROM student_fees WHERE fee_structure_id = ? LIMIT 1').get(id);
  if (assigned) {
    throw new AppError('Cannot delete fee structure assigned to students', 400, 'FEE_STRUCTURE_IN_USE');
  }

  db.prepare('DELETE FROM fee_structure WHERE id = ?').run(id);
  res.json({ success: true, message: 'Fee structure deleted successfully' });
});

export const getStudentFees = asyncHandler(async (req, res) => {
  const { studentId } = req.params;
  const { academic_year_id, status } = req.query;

  let where = 'WHERE sf.student_id = ?';
  const params = [studentId];

  if (academic_year_id) { where += ' AND sf.academic_year_id = ?'; params.push(academic_year_id); }
  if (status) { where += ' AND sf.status = ?'; params.push(status); }

  const fees = db.prepare(`
    SELECT sf.*, fs.name, fs.description, fs.class_level, fs.programme, ay.name as academic_year
    FROM student_fees sf
    JOIN fee_structure fs ON sf.fee_structure_id = fs.id
    JOIN academic_years ay ON sf.academic_year_id = ay.id
    ${where}
    ORDER BY sf.due_date
  `).all(...params);

  res.json({ success: true, data: fees });
});

export const assignFeeToStudent = asyncHandler(async (req, res) => {
  const { studentId } = req.params;
  const { fee_structure_id, academic_year_id, amount_due, due_date } = req.body;

  const student = db.prepare('SELECT * FROM students WHERE id = ?').get(studentId);
  if (!student) {
    throw new AppError('Student not found', 404, 'STUDENT_NOT_FOUND');
  }

  const structure = db.prepare('SELECT * FROM fee_structure WHERE id = ?').get(fee_structure_id);
  if (!structure) {
    throw new AppError('Fee structure not found', 404, 'FEE_STRUCTURE_NOT_FOUND');
  }

  const existing = db.prepare(`
    SELECT * FROM student_fees WHERE student_id = ? AND fee_structure_id = ? AND academic_year_id = ?
  `).get(studentId, fee_structure_id, academic_year_id);

  const now = formatDate();
  const amount = amount_due || structure.amount;

  if (existing) {
    throw new AppError('Fee already assigned to this student for this academic year', 409, 'FEE_ALREADY_ASSIGNED');
  }

  const id = generateId();
  db.prepare(`
    INSERT INTO student_fees (id, student_id, fee_structure_id, academic_year_id, amount_due, due_date, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)
  `).run(id, studentId, fee_structure_id, academic_year_id, amount, due_date || structure.due_date, now, now);

  const fee = db.prepare('SELECT * FROM student_fees WHERE id = ?').get(id);
  res.status(201).json({ success: true, message: 'Fee assigned successfully', data: fee });
});

export const recordPayment = asyncHandler(async (req, res) => {
  const { student_id, student_fee_id, amount, payment_method, reference, description } = req.body;

  const student = db.prepare('SELECT * FROM students WHERE id = ?').get(student_id);
  if (!student) {
    throw new AppError('Student not found', 404, 'STUDENT_NOT_FOUND');
  }

  let fee = null;
  if (student_fee_id) {
    fee = db.prepare('SELECT * FROM student_fees WHERE id = ? AND student_id = ?').get(student_fee_id, student_id);
    if (!fee) {
      throw new AppError('Student fee not found', 404, 'STUDENT_FEE_NOT_FOUND');
    }
  }

  const now = formatDate();
  const paymentId = generateId();
  const paymentRef = reference || `PAY-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

  db.prepare(`
    INSERT INTO payments (id, student_id, student_fee_id, amount, payment_method, reference, description, status, paid_at, recorded_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?)
  `).run(paymentId, student_id, student_fee_id, amount, payment_method, paymentRef, description, now, req.user.id);

  if (fee) {
    const newPaid = fee.amount_paid + amount;
    const newBalance = fee.amount_due - newPaid;
    let newStatus = 'partial';
    if (newBalance <= 0) newStatus = 'paid';
    else if (newPaid === 0) newStatus = 'pending';

    db.prepare(`
      UPDATE student_fees SET amount_paid = ?, status = ?, updated_at = ? WHERE id = ?
    `).run(newPaid, newStatus, now, fee.id);
  }

  const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId);
  res.status(201).json({ success: true, message: 'Payment recorded successfully', data: payment });
});

export const getStudentPayments = asyncHandler(async (req, res) => {
  const { studentId } = req.params;
  const { page = 1, limit = 20 } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const payments = db.prepare(`
    SELECT p.*, sf.amount_due, fs.name as fee_name, ay.name as academic_year
    FROM payments p
    LEFT JOIN student_fees sf ON p.student_fee_id = sf.id
    LEFT JOIN fee_structure fs ON sf.fee_structure_id = fs.id
    LEFT JOIN academic_years ay ON sf.academic_year_id = ay.id
    WHERE p.student_id = ?
    ORDER BY p.paid_at DESC
    LIMIT ? OFFSET ?
  `).all(studentId, lim, offset);

  const total = db.prepare('SELECT COUNT(*) as count FROM payments WHERE student_id = ?').get(studentId).count;

  res.json({
    success: true,
    data: payments,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});

export const getOverdueFees = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const { limit: lim, offset } = paginate(page, limit);
  const today = formatDateOnly();

  const fees = db.prepare(`
    SELECT sf.*, s.student_id, u.full_name as student_name, fs.name as fee_name, fs.amount as fee_amount, ay.name as academic_year
    FROM student_fees sf
    JOIN students s ON sf.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN fee_structure fs ON sf.fee_structure_id = fs.id
    JOIN academic_years ay ON sf.academic_year_id = ay.id
    WHERE sf.status IN ('pending', 'partial', 'overdue') AND sf.due_date < ?
    ORDER BY sf.due_date
    LIMIT ? OFFSET ?
  `).all(today, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(*) as count FROM student_fees 
    WHERE status IN ('pending', 'partial', 'overdue') AND due_date < ?
  `).get(today).count;

  res.json({
    success: true,
    data: fees,
    pagination: { page: parseInt(page), limit: lim, total, pages: Math.ceil(total / lim) }
  });
});