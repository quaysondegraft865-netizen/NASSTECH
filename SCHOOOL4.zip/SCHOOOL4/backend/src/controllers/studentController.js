import db from '../config/database.js';
import { 
  generateId, 
  hashPassword, 
  sanitizeUser, 
  formatDate, 
  formatDateOnly,
  paginate, 
  buildWhereClause, 
  buildOrderBy,
  asyncHandler,
  AppError 
} from '../utils/helpers.js';

export const getAllStudents = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, search, programme, level, status } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const filters = {};
  if (search) filters.search = search;
  if (programme) filters.programme = programme;
  if (level) filters.level = level;
  if (status) filters.student_status = status;

  const allowedFields = ['programme', 'level', 'student_status'];
  let whereClause = '';
  let params = [];

  if (search) {
    whereClause = `WHERE (s.student_id LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)`;
    const searchTerm = `%${search}%`;
    params = [searchTerm, searchTerm, searchTerm];
  }

  if (programme || level || status) {
    const conditions = [];
    if (programme) { conditions.push('s.programme = ?'); params.push(programme); }
    if (level) { conditions.push('s.level = ?'); params.push(level); }
    if (status) { conditions.push('s.status = ?'); params.push(status); }
    
    if (whereClause) {
      whereClause += ` AND ${conditions.join(' AND ')}`;
    } else {
      whereClause = `WHERE ${conditions.join(' AND ')}`;
    }
  }

  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['student_id', 'full_name', 'created_at'], 's.student_id');

  const countQuery = `
    SELECT COUNT(*) as total 
    FROM students s
    JOIN users u ON s.user_id = u.id
    ${whereClause}
  `;
  const { total } = db.prepare(countQuery).get(...params);

  const dataQuery = `
    SELECT s.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active, u.last_login_at, u.created_at as user_created_at
    FROM students s
    JOIN users u ON s.user_id = u.id
    ${whereClause}
    ${orderBy}
    LIMIT ? OFFSET ?
  `;
  const students = db.prepare(dataQuery).all(...params, lim, offset);

  res.json({
    success: true,
    data: students,
    pagination: {
      page: parseInt(page),
      limit: lim,
      total,
      totalPages: Math.ceil(total / lim)
    }
  });
});

export const getStudentById = asyncHandler(async (req, res) => {
  const student = db.prepare(`
    SELECT s.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active, u.last_login_at, u.created_at as user_created_at
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
  `).get(req.params.id);

  if (!student) {
    throw new AppError('Student not found', 404, 'STUDENT_NOT_FOUND');
  }

  res.json({ success: true, data: student });
});

export const createStudent = asyncHandler(async (req, res) => {
  const {
    student_id, email, password, full_name, programme, level, admission_year,
    date_of_birth, gender, phone, guardian_name, guardian_phone, guardian_email,
    address, department, semester = 'First'
  } = req.body;

  const existingStudent = db.prepare('SELECT id FROM students WHERE student_id = ?').get(student_id);
  if (existingStudent) {
    throw new AppError('Student ID already exists', 409, 'DUPLICATE_STUDENT_ID');
  }

  const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existingUser) {
    throw new AppError('Email already registered', 409, 'DUPLICATE_EMAIL');
  }

  const userId = generateId();
  const studentId = generateId();
  const passwordHash = await hashPassword(password);
  const now = formatDate();

  db.exec('BEGIN TRANSACTION');
  try {
    db.prepare(`
      INSERT INTO users (id, email, password_hash, role, full_name, phone, created_at, updated_at)
      VALUES (?, ?, ?, 'student', ?, ?, ?, ?)
    `).run(userId, email, passwordHash, full_name, phone || null, now, now);

    db.prepare(`
      INSERT INTO students (id, user_id, student_id, programme, level, semester, admission_year,
        date_of_birth, gender, address, guardian_name, guardian_phone, guardian_email, department, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(studentId, userId, student_id, programme, level, semester, admission_year,
      date_of_birth, gender, address || null, guardian_name || null, guardian_phone || null,
      guardian_email || null, department || null, now, now);

    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  const student = db.prepare(`
    SELECT s.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
  `).get(studentId);

  res.status(201).json({ success: true, message: 'Student created successfully', data: student });
});

export const updateStudent = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  const student = db.prepare('SELECT * FROM students WHERE id = ?').get(id);
  if (!student) {
    throw new AppError('Student not found', 404, 'STUDENT_NOT_FOUND');
  }

  const userUpdates = {};
  const studentUpdates = {};
  const now = formatDate();

  const userFields = ['email', 'full_name', 'phone', 'avatar_url'];
  const studentFields = ['programme', 'level', 'status', 'guardian_name', 'guardian_phone', 'guardian_email', 'address', 'department'];

  for (const field of userFields) {
    if (updates[field] !== undefined) userUpdates[field] = updates[field];
  }
  for (const field of studentFields) {
    if (updates[field] !== undefined) studentUpdates[field] = updates[field];
  }

  if (Object.keys(userUpdates).length > 0) {
    const setClause = Object.keys(userUpdates).map(k => `${k} = ?`).join(', ');
    const values = [...Object.values(userUpdates), now, student.user_id];
    db.prepare(`UPDATE users SET ${setClause}, updated_at = ? WHERE id = ?`).run(...values);
  }

  if (Object.keys(studentUpdates).length > 0) {
    const setClause = Object.keys(studentUpdates).map(k => `${k} = ?`).join(', ');
    const values = [...Object.values(studentUpdates), now, id];
    db.prepare(`UPDATE students SET ${setClause}, updated_at = ? WHERE id = ?`).run(...values);
  }

  const updated = db.prepare(`
    SELECT s.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
  `).get(id);

  res.json({ success: true, message: 'Student updated successfully', data: updated });
});

export const deleteStudent = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const student = db.prepare('SELECT user_id FROM students WHERE id = ?').get(id);
  if (!student) {
    throw new AppError('Student not found', 404, 'STUDENT_NOT_FOUND');
  }

  db.exec('BEGIN TRANSACTION');
  try {
    db.prepare('DELETE FROM students WHERE id = ?').run(id);
    db.prepare('DELETE FROM users WHERE id = ?').run(student.user_id);
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  res.json({ success: true, message: 'Student deleted successfully' });
});

export const getStudentEnrollments = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const enrollments = db.prepare(`
    SELECT e.*, c.name as class_name, c.code as class_code, c.form_level, ay.name as academic_year
    FROM enrollments e
    JOIN classes c ON e.class_id = c.id
    JOIN academic_years ay ON e.academic_year_id = ay.id
    WHERE e.student_id = ?
    ORDER BY ay.start_date DESC
  `).all(id);

  res.json({ success: true, data: enrollments });
});

export const getStudentGrades = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { academic_year_id, semester_id } = req.query;

  let query = `
    SELECT g.*, s.name as subject_name, s.code as subject_code, s.credits,
           c.name as class_name, ay.name as academic_year, sem.name as semester
    FROM grades g
    JOIN subjects s ON g.subject_id = s.id
    JOIN classes c ON g.class_id = c.id
    JOIN academic_years ay ON g.academic_year_id = ay.id
    JOIN semesters sem ON g.semester_id = sem.id
    WHERE g.student_id = ?
  `;
  const params = [id];

  if (academic_year_id) {
    query += ' AND g.academic_year_id = ?';
    params.push(academic_year_id);
  }
  if (semester_id) {
    query += ' AND g.semester_id = ?';
    params.push(semester_id);
  }

  query += ' ORDER BY g.entered_at DESC';

  const grades = db.prepare(query).all(...params);
  res.json({ success: true, data: grades });
});

export const getStudentAttendance = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { start_date, end_date, subject_id } = req.query;

  let query = `
    SELECT a.*, s.name as subject_name, s.code as subject_code, c.name as class_name
    FROM attendance a
    JOIN subjects s ON a.subject_id = s.id
    JOIN classes c ON a.class_id = c.id
    WHERE a.student_id = ?
  `;
  const params = [id];

  if (start_date) {
    query += ' AND a.date >= ?';
    params.push(start_date);
  }
  if (end_date) {
    query += ' AND a.date <= ?';
    params.push(end_date);
  }
  if (subject_id) {
    query += ' AND a.subject_id = ?';
    params.push(subject_id);
  }

  query += ' ORDER BY a.date DESC';

  const attendance = db.prepare(query).all(...params);
  res.json({ success: true, data: attendance });
});

export const getStudentFees = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { academic_year_id } = req.query;

  let query = `
    SELECT sf.*, fs.name as fee_name, fs.description, fs.amount as fee_amount,
           ay.name as academic_year
    FROM student_fees sf
    JOIN fee_structure fs ON sf.fee_structure_id = fs.id
    JOIN academic_years ay ON sf.academic_year_id = ay.id
    WHERE sf.student_id = ?
  `;
  const params = [id];

  if (academic_year_id) {
    query += ' AND sf.academic_year_id = ?';
    params.push(academic_year_id);
  }

  query += ' ORDER BY sf.due_date ASC';

  const fees = db.prepare(query).all(...params);
  res.json({ success: true, data: fees });
});

export const bulkImportStudents = asyncHandler(async (req, res) => {
  const { students } = req.body;
  const results = { created: 0, failed: [], errors: [] };
  const now = formatDate();

  for (const [index, studentData] of students.entries()) {
    try {
      const { student_id, email, password, full_name, programme, level, admission_year,
        date_of_birth, gender, phone, guardian_name, guardian_phone, guardian_email,
        address, department, semester = 'First' } = studentData;

      if (!student_id || !email || !password || !full_name || !programme || !level || !admission_year || !date_of_birth || !gender) {
        results.failed.push({ index, student_id, error: 'Missing required fields' });
        continue;
      }

      const existingStudent = db.prepare('SELECT id FROM students WHERE student_id = ?').get(student_id);
      if (existingStudent) {
        results.failed.push({ index, student_id, error: 'Student ID already exists' });
        continue;
      }

      const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
      if (existingUser) {
        results.failed.push({ index, student_id, error: 'Email already registered' });
        continue;
      }

      const userId = generateId();
      const studentId = generateId();
      const passwordHash = await hashPassword(password);

      db.exec('BEGIN TRANSACTION');
      try {
        db.prepare(`
          INSERT INTO users (id, email, password_hash, role, full_name, phone, created_at, updated_at)
          VALUES (?, ?, ?, 'student', ?, ?, ?, ?)
        `).run(userId, email, passwordHash, full_name, phone || null, now, now);

        db.prepare(`
          INSERT INTO students (id, user_id, student_id, programme, level, semester, admission_year,
            date_of_birth, gender, address, guardian_name, guardian_phone, guardian_email, department, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(studentId, userId, student_id, programme, level, semester, admission_year,
          date_of_birth, gender, address || null, guardian_name || null, guardian_phone || null,
          guardian_email || null, department || null, now, now);

        db.exec('COMMIT');
        results.created++;
      } catch (error) {
        db.exec('ROLLBACK');
        results.failed.push({ index, student_id, error: error.message });
      }
    } catch (error) {
      results.failed.push({ index, student_id: studentData.student_id, error: error.message });
    }
  }

  res.json({
    success: true,
    message: `Import completed: ${results.created} created, ${results.failed.length} failed`,
    data: results
  });
});