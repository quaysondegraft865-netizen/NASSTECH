import db from '../config/database.js';
import { 
  generateId, 
  hashPassword, 
  sanitizeUser, 
  formatDate, 
  paginate, 
  buildWhereClause, 
  buildOrderBy,
  asyncHandler,
  AppError 
} from '../utils/helpers.js';

export const getAllTeachers = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, search, department, designation } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  let whereClause = '';
  const params = [];

  if (search) {
    whereClause = `WHERE (t.staff_id LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)`;
    const searchTerm = `%${search}%`;
    params.push(searchTerm, searchTerm, searchTerm);
  }

  if (department || designation) {
    const conditions = [];
    if (department) { conditions.push('t.department = ?'); params.push(department); }
    if (designation) { conditions.push('t.designation = ?'); params.push(designation); }
    
    if (whereClause) {
      whereClause += ` AND ${conditions.join(' AND ')}`;
    } else {
      whereClause = `WHERE ${conditions.join(' AND ')}`;
    }
  }

  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['staff_id', 'full_name', 'created_at'], 't.staff_id');

  const countQuery = `
    SELECT COUNT(*) as total 
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    ${whereClause}
  `;
  const { total } = db.prepare(countQuery).get(...params);

  const dataQuery = `
    SELECT t.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active, u.last_login_at, u.role, u.created_at as user_created_at
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    ${whereClause}
    ${orderBy}
    LIMIT ? OFFSET ?
  `;
  const teachers = db.prepare(dataQuery).all(...params, lim, offset);

  res.json({
    success: true,
    data: teachers,
    pagination: {
      page: parseInt(page),
      limit: lim,
      total,
      totalPages: Math.ceil(total / lim)
    }
  });
});

export const getTeacherById = asyncHandler(async (req, res) => {
  const teacher = db.prepare(`
    SELECT t.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active, u.last_login_at, u.role, u.created_at as user_created_at
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    WHERE t.id = ?
  `).get(req.params.id);

  if (!teacher) {
    throw new AppError('Teacher not found', 404, 'TEACHER_NOT_FOUND');
  }

  res.json({ success: true, data: teacher });
});

export const createTeacher = asyncHandler(async (req, res) => {
  const {
    staff_id, email, password, full_name, role, department, designation,
    qualification, specialization, hire_date, salary_grade, max_workload = 24, phone
  } = req.body;

  const existingTeacher = db.prepare('SELECT id FROM teachers WHERE staff_id = ?').get(staff_id);
  if (existingTeacher) {
    throw new AppError('Staff ID already exists', 409, 'DUPLICATE_STAFF_ID');
  }

  const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existingUser) {
    throw new AppError('Email already registered', 409, 'DUPLICATE_EMAIL');
  }

  const userId = generateId();
  const teacherId = generateId();
  const passwordHash = await hashPassword(password);
  const now = formatDate();

  db.exec('BEGIN TRANSACTION');
  try {
    db.prepare(`
      INSERT INTO users (id, email, password_hash, role, full_name, phone, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(userId, email, passwordHash, role, full_name, phone || null, now, now);

    db.prepare(`
      INSERT INTO teachers (id, user_id, staff_id, department, designation, qualification,
        specialization, hire_date, salary_grade, max_workload, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(teacherId, userId, staff_id, department, designation || null, qualification || null,
      specialization || null, hire_date, salary_grade || null, max_workload, now, now);

    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  const teacher = db.prepare(`
    SELECT t.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active, u.role
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    WHERE t.id = ?
  `).get(teacherId);

  res.status(201).json({ success: true, message: 'Teacher created successfully', data: teacher });
});

export const updateTeacher = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  const teacher = db.prepare('SELECT * FROM teachers WHERE id = ?').get(id);
  if (!teacher) {
    throw new AppError('Teacher not found', 404, 'TEACHER_NOT_FOUND');
  }

  const userUpdates = {};
  const teacherUpdates = {};
  const now = formatDate();

  const userFields = ['email', 'full_name', 'phone', 'avatar_url', 'role'];
  const teacherFields = ['department', 'designation', 'qualification', 'specialization', 'salary_grade', 'max_workload'];

  for (const field of userFields) {
    if (updates[field] !== undefined) userUpdates[field] = updates[field];
  }
  for (const field of teacherFields) {
    if (updates[field] !== undefined) teacherUpdates[field] = updates[field];
  }

  if (Object.keys(userUpdates).length > 0) {
    const setClause = Object.keys(userUpdates).map(k => `${k} = ?`).join(', ');
    const values = [...Object.values(userUpdates), now, teacher.user_id];
    db.prepare(`UPDATE users SET ${setClause}, updated_at = ? WHERE id = ?`).run(...values);
  }

  if (Object.keys(teacherUpdates).length > 0) {
    const setClause = Object.keys(teacherUpdates).map(k => `${k} = ?`).join(', ');
    const values = [...Object.values(teacherUpdates), now, id];
    db.prepare(`UPDATE teachers SET ${setClause}, updated_at = ? WHERE id = ?`).run(...values);
  }

  const updated = db.prepare(`
    SELECT t.*, u.email, u.full_name, u.phone, u.avatar_url, u.is_active, u.role
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    WHERE t.id = ?
  `).get(id);

  res.json({ success: true, message: 'Teacher updated successfully', data: updated });
});

export const deleteTeacher = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const teacher = db.prepare('SELECT user_id FROM teachers WHERE id = ?').get(id);
  if (!teacher) {
    throw new AppError('Teacher not found', 404, 'TEACHER_NOT_FOUND');
  }

  db.exec('BEGIN TRANSACTION');
  try {
    db.prepare('DELETE FROM teachers WHERE id = ?').run(id);
    db.prepare('DELETE FROM users WHERE id = ?').run(teacher.user_id);
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }

  res.json({ success: true, message: 'Teacher deleted successfully' });
});

export const getTeacherAssignments = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { academic_year_id } = req.query;

  let query = `
    SELECT ta.*, c.name as class_name, c.code as class_code, c.form_level,
           s.name as subject_name, s.code as subject_code,
           ay.name as academic_year
    FROM teacher_assignments ta
    JOIN classes c ON ta.class_id = c.id
    JOIN subjects s ON ta.subject_id = s.id
    JOIN academic_years ay ON ta.academic_year_id = ay.id
    WHERE ta.teacher_id = ?
  `;
  const params = [id];

  if (academic_year_id) {
    query += ' AND ta.academic_year_id = ?';
    params.push(academic_year_id);
  }

  query += ' ORDER BY ay.start_date DESC, c.name, s.name';

  const assignments = db.prepare(query).all(...params);
  res.json({ success: true, data: assignments });
});

export const getTeacherClasses = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { academic_year_id } = req.query;

  let query = `
    SELECT DISTINCT c.*, ay.name as academic_year
    FROM classes c
    JOIN teacher_assignments ta ON c.id = ta.class_id
    JOIN academic_years ay ON c.academic_year_id = ay.id
    WHERE ta.teacher_id = ? AND ta.status = 'active'
  `;
  const params = [id];

  if (academic_year_id) {
    query += ' AND ta.academic_year_id = ?';
    params.push(academic_year_id);
  }

  query += ' ORDER BY c.form_level, c.name';

  const classes = db.prepare(query).all(...params);
  res.json({ success: true, data: classes });
});

export const assignTeacher = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { class_id, subject_id, academic_year_id, periods_per_week = 4 } = req.body;

  const teacher = db.prepare('SELECT id FROM teachers WHERE id = ?').get(id);
  if (!teacher) {
    throw new AppError('Teacher not found', 404, 'TEACHER_NOT_FOUND');
  }

  const classExists = db.prepare('SELECT id FROM classes WHERE id = ?').get(class_id);
  if (!classExists) {
    throw new AppError('Class not found', 404, 'CLASS_NOT_FOUND');
  }

  const subject = db.prepare('SELECT id FROM subjects WHERE id = ?').get(subject_id);
  if (!subject) {
    throw new AppError('Subject not found', 404, 'SUBJECT_NOT_FOUND');
  }

  const academicYear = db.prepare('SELECT id FROM academic_years WHERE id = ?').get(academic_year_id);
  if (!academicYear) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const existing = db.prepare(`
    SELECT id FROM teacher_assignments 
    WHERE teacher_id = ? AND class_id = ? AND subject_id = ? AND academic_year_id = ?
  `).get(id, class_id, subject_id, academic_year_id);

  if (existing) {
    throw new AppError('Assignment already exists', 409, 'ASSIGNMENT_EXISTS');
  }

  const assignmentId = generateId();
  const now = formatDate();

  db.prepare(`
    INSERT INTO teacher_assignments (id, teacher_id, class_id, subject_id, academic_year_id, periods_per_week, assigned_by, assigned_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(assignmentId, id, class_id, subject_id, academic_year_id, periods_per_week, req.user.id, now);

  const assignment = db.prepare(`
    SELECT ta.*, c.name as class_name, c.code as class_code, s.name as subject_name, s.code as subject_code, ay.name as academic_year
    FROM teacher_assignments ta
    JOIN classes c ON ta.class_id = c.id
    JOIN subjects s ON ta.subject_id = s.id
    JOIN academic_years ay ON ta.academic_year_id = ay.id
    WHERE ta.id = ?
  `).get(assignmentId);

  res.status(201).json({ success: true, message: 'Teacher assigned successfully', data: assignment });
});

export const removeAssignment = asyncHandler(async (req, res) => {
  const { id, assignmentId } = req.params;

  const assignment = db.prepare('SELECT id FROM teacher_assignments WHERE id = ? AND teacher_id = ?').get(assignmentId, id);
  if (!assignment) {
    throw new AppError('Assignment not found', 404, 'ASSIGNMENT_NOT_FOUND');
  }

  db.prepare('DELETE FROM teacher_assignments WHERE id = ?').run(assignmentId);

  res.json({ success: true, message: 'Assignment removed successfully' });
});