import db from '../config/database.js';
import {
  generateId,
  formatDate,
  formatDateOnly,
  asyncHandler,
  AppError,
  paginate,
  buildWhereClause,
  buildOrderBy
} from '../utils/helpers.js';

export const getDashboardStats = asyncHandler(async (req, res) => {
  const students = db.prepare('SELECT COUNT(*) as count FROM students').get().count;
  const activeStudents = db.prepare(`
    SELECT COUNT(DISTINCT student_id) as count FROM enrollments
    WHERE status = 'active' AND academic_year_id = (
      SELECT id FROM academic_years WHERE is_current = 1 LIMIT 1
    )
  `).get().count;
  const teachers = db.prepare('SELECT COUNT(*) as count FROM teachers').get().count;
  const classes = db.prepare(`
    SELECT COUNT(*) as count FROM classes
    WHERE academic_year_id = (SELECT id FROM academic_years WHERE is_current = 1 LIMIT 1)
  `).get().count;
  const subjects = db.prepare('SELECT COUNT(*) as count FROM subjects WHERE is_active = 1').get().count;

  const today = formatDateOnly();
  const attendanceToday = db.prepare(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN status IN ('present', 'late') THEN 1 ELSE 0 END) as present
    FROM attendance WHERE date = ?
  `).get(today);

  const feeSummary = db.prepare(`
    SELECT
      COALESCE(SUM(amount_due), 0) as total_expected,
      COALESCE(SUM(amount_paid), 0) as total_collected
    FROM student_fees
    WHERE academic_year_id = (SELECT id FROM academic_years WHERE is_current = 1 LIMIT 1)
  `).get();

  const pendingFees = db.prepare(`
    SELECT COUNT(*) as count FROM student_fees WHERE status IN ('pending', 'partial', 'overdue')
  `).get().count;

  const currentYear = db.prepare('SELECT * FROM academic_years WHERE is_current = 1 LIMIT 1').get();
  const currentSemester = currentYear
    ? db.prepare('SELECT * FROM semesters WHERE academic_year_id = ? AND is_current = 1 LIMIT 1').get(currentYear.id)
    : null;

  const pendingAssessments = db.prepare(`
    SELECT COUNT(*) as count FROM assessment_sheets WHERE status IN ('draft', 'submitted')
  `).get().count;

  res.json({
    success: true,
    data: {
      students: { total: students, active: activeStudents },
      teachers: { total: teachers },
      classes: { total: classes },
      subjects: { total: subjects },
      attendance: {
        date: today,
        total: attendanceToday.total || 0,
        present: attendanceToday.present || 0,
        rate: attendanceToday.total > 0 ? parseFloat((attendanceToday.present / attendanceToday.total * 100).toFixed(2)) : 0
      },
      fees: {
        totalExpected: feeSummary.total_expected,
        totalCollected: feeSummary.total_collected,
        collectionRate: feeSummary.total_expected > 0
          ? parseFloat((feeSummary.total_collected / feeSummary.total_expected * 100).toFixed(2)) : 0,
        pendingCount: pendingFees
      },
      currentAcademicYear: currentYear,
      currentSemester: currentSemester,
      pendingAssessments
    }
  });
});

export const getActivityLogs = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, action, entity_type } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const conditions = [];
  const params = [];

  if (action) { conditions.push('al.action LIKE ?'); params.push(`%${action}%`); }
  if (entity_type) { conditions.push('al.entity_type = ?'); params.push(entity_type); }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const logs = db.prepare(`
    SELECT al.*, u.full_name as user_name, u.email as user_email
    FROM activity_logs al
    LEFT JOIN users u ON al.user_id = u.id
    ${whereClause}
    ORDER BY al.created_at DESC
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`SELECT COUNT(*) as count FROM activity_logs ${whereClause}`).get(...params).count;

  res.json({
    success: true,
    data: logs,
    pagination: { page: parseInt(page), limit: lim, total, totalPages: Math.ceil(total / lim) }
  });
});

export const logActivity = (userId, action, entityType = null, entityId = null, details = null, ipAddress = null, userAgent = null) => {
  try {
    const id = generateId();
    db.prepare(`
      INSERT INTO activity_logs (id, user_id, action, entity_type, entity_id, details, ip_address, user_agent, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, userId, action, entityType, entityId, details, ipAddress, userAgent, formatDate());
  } catch (error) {
    console.error('Error logging activity:', error);
  }
};

export const getAllUsers = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, search, role, is_active } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const conditions = [];
  const params = [];

  if (search) {
    conditions.push('(u.full_name LIKE ? OR u.email LIKE ?)');
    const term = `%${search}%`;
    params.push(term, term);
  }
  if (role) { conditions.push('u.role = ?'); params.push(role); }
  if (is_active !== undefined) {
    conditions.push('u.is_active = ?');
    params.push(is_active === 'true' ? 1 : 0);
  }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const orderBy = buildOrderBy(req.query.sortBy, req.query.sortOrder, ['full_name', 'role', 'created_at', 'last_login_at'], 'u.created_at');

  const users = db.prepare(`
    SELECT u.id, u.email, u.role, u.full_name, u.phone, u.is_active, u.last_login_at, u.created_at
    FROM users u
    ${whereClause}
    ${orderBy}
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`SELECT COUNT(*) as count FROM users u ${whereClause}`).get(...params).count;

  res.json({
    success: true,
    data: users,
    pagination: { page: parseInt(page), limit: lim, total, totalPages: Math.ceil(total / lim) }
  });
});

export const activateUser = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const user = db.prepare('SELECT id, full_name FROM users WHERE id = ?').get(id);
  if (!user) {
    throw new AppError('User not found', 404, 'USER_NOT_FOUND');
  }

  db.prepare('UPDATE users SET is_active = 1, updated_at = ? WHERE id = ?').run(formatDate(), id);

  logActivity(req.user.id, 'user.activated', 'user', id, `Activated user ${user.full_name}`, req.ip, req.get('user-agent'));

  res.json({ success: true, message: 'User activated successfully' });
});

export const deactivateUser = asyncHandler(async (req, res) => {
  const { id } = req.params;

  if (id === req.user.id) {
    throw new AppError('Cannot deactivate your own account', 400, 'CANNOT_DEACTIVATE_SELF');
  }

  const user = db.prepare('SELECT id, full_name FROM users WHERE id = ?').get(id);
  if (!user) {
    throw new AppError('User not found', 404, 'USER_NOT_FOUND');
  }

  db.prepare('UPDATE users SET is_active = 0, updated_at = ? WHERE id = ?').run(formatDate(), id);

  logActivity(req.user.id, 'user.deactivated', 'user', id, `Deactivated user ${user.full_name}`, req.ip, req.get('user-agent'));

  res.json({ success: true, message: 'User deactivated successfully' });
});

export const getAllAcademicYears = asyncHandler(async (req, res) => {
  const years = db.prepare(`
    SELECT ay.*,
      (SELECT COUNT(*) FROM semesters s WHERE s.academic_year_id = ay.id) as semester_count,
      (SELECT COUNT(*) FROM classes c WHERE c.academic_year_id = ay.id) as class_count
    FROM academic_years ay
    ORDER BY ay.start_date DESC
  `).all();

  res.json({ success: true, data: years });
});

export const getAcademicYearById = asyncHandler(async (req, res) => {
  const year = db.prepare(`
    SELECT ay.*,
      (SELECT COUNT(*) FROM semesters s WHERE s.academic_year_id = ay.id) as semester_count,
      (SELECT COUNT(*) FROM classes c WHERE c.academic_year_id = ay.id) as class_count
    FROM academic_years ay
    WHERE ay.id = ?
  `).get(req.params.id);

  if (!year) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const semesters = db.prepare('SELECT * FROM semesters WHERE academic_year_id = ? ORDER BY start_date').all(req.params.id);

  res.json({ success: true, data: { ...year, semesters } });
});

export const createAcademicYear = asyncHandler(async (req, res) => {
  const { name, start_date, end_date, is_current = false } = req.body;

  const existing = db.prepare('SELECT id FROM academic_years WHERE name = ?').get(name);
  if (existing) {
    throw new AppError('Academic year already exists', 409, 'DUPLICATE_ACADEMIC_YEAR');
  }

  const id = generateId();
  const now = formatDate();

  if (is_current) {
    db.prepare('UPDATE academic_years SET is_current = 0 WHERE is_current = 1').run();
  }

  db.prepare(`
    INSERT INTO academic_years (id, name, start_date, end_date, is_current, is_active, created_at)
    VALUES (?, ?, ?, ?, ?, 1, ?)
  `).run(id, name, start_date, end_date, is_current ? 1 : 0, now);

  const year = db.prepare('SELECT * FROM academic_years WHERE id = ?').get(id);

  logActivity(req.user.id, 'academic_year.created', 'academic_year', id, `Created academic year ${name}`, req.ip, req.get('user-agent'));

  res.status(201).json({ success: true, message: 'Academic year created successfully', data: year });
});

export const updateAcademicYear = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, start_date, end_date, is_current, is_active } = req.body;

  const year = db.prepare('SELECT * FROM academic_years WHERE id = ?').get(id);
  if (!year) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  if (name && name !== year.name) {
    const existing = db.prepare('SELECT id FROM academic_years WHERE name = ? AND id != ?').get(name, id);
    if (existing) {
      throw new AppError('Academic year already exists', 409, 'DUPLICATE_ACADEMIC_YEAR');
    }
  }

  if (is_current) {
    db.prepare('UPDATE academic_years SET is_current = 0 WHERE is_current = 1').run();
  }

  const updates = [];
  const params = [];
  if (name) { updates.push('name = ?'); params.push(name); }
  if (start_date) { updates.push('start_date = ?'); params.push(start_date); }
  if (end_date) { updates.push('end_date = ?'); params.push(end_date); }
  if (is_current !== undefined) { updates.push('is_current = ?'); params.push(is_current ? 1 : 0); }
  if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }

  if (updates.length) {
    params.push(id);
    db.prepare(`UPDATE academic_years SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }

  const updated = db.prepare('SELECT * FROM academic_years WHERE id = ?').get(id);
  res.json({ success: true, message: 'Academic year updated successfully', data: updated });
});

export const deleteAcademicYear = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const year = db.prepare('SELECT * FROM academic_years WHERE id = ?').get(id);
  if (!year) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const inUse = db.prepare('SELECT 1 FROM classes WHERE academic_year_id = ? LIMIT 1').get(id);
  if (inUse) {
    throw new AppError('Cannot delete academic year with existing classes', 400, 'ACADEMIC_YEAR_IN_USE');
  }

  db.prepare('DELETE FROM semesters WHERE academic_year_id = ?').run(id);
  db.prepare('DELETE FROM academic_years WHERE id = ?').run(id);

  logActivity(req.user.id, 'academic_year.deleted', 'academic_year', id, `Deleted academic year ${year.name}`, req.ip, req.get('user-agent'));

  res.json({ success: true, message: 'Academic year deleted successfully' });
});

export const getAllSemesters = asyncHandler(async (req, res) => {
  const { academic_year_id } = req.query;

  let query = `
    SELECT s.*, ay.name as academic_year
    FROM semesters s
    JOIN academic_years ay ON s.academic_year_id = ay.id
  `;
  const params = [];

  if (academic_year_id) {
    query += ' WHERE s.academic_year_id = ?';
    params.push(academic_year_id);
  }

  query += ' ORDER BY ay.start_date DESC, s.start_date';

  const semesters = db.prepare(query).all(...params);
  res.json({ success: true, data: semesters });
});

export const createSemester = asyncHandler(async (req, res) => {
  const { academic_year_id, name, start_date, end_date, is_current = false } = req.body;

  const academicYear = db.prepare('SELECT id FROM academic_years WHERE id = ?').get(academic_year_id);
  if (!academicYear) {
    throw new AppError('Academic year not found', 404, 'ACADEMIC_YEAR_NOT_FOUND');
  }

  const existing = db.prepare('SELECT id FROM semesters WHERE academic_year_id = ? AND name = ?').get(academic_year_id, name);
  if (existing) {
    throw new AppError('Semester already exists for this academic year', 409, 'DUPLICATE_SEMESTER');
  }

  if (is_current) {
    db.prepare('UPDATE semesters SET is_current = 0 WHERE academic_year_id = ?').run(academic_year_id);
  }

  const id = generateId();
  const now = formatDate();

  db.prepare(`
    INSERT INTO semesters (id, academic_year_id, name, start_date, end_date, is_current, is_active, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
  `).run(id, academic_year_id, name, start_date, end_date, is_current ? 1 : 0, now);

  const semester = db.prepare('SELECT * FROM semesters WHERE id = ?').get(id);

  logActivity(req.user.id, 'semester.created', 'semester', id, `Created semester ${name}`, req.ip, req.get('user-agent'));

  res.status(201).json({ success: true, message: 'Semester created successfully', data: semester });
});

export const updateSemester = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, start_date, end_date, is_current, is_active } = req.body;

  const semester = db.prepare('SELECT * FROM semesters WHERE id = ?').get(id);
  if (!semester) {
    throw new AppError('Semester not found', 404, 'SEMESTER_NOT_FOUND');
  }

  if (name && name !== semester.name) {
    const existing = db.prepare('SELECT id FROM semesters WHERE academic_year_id = ? AND name = ? AND id != ?')
      .get(semester.academic_year_id, name, id);
    if (existing) {
      throw new AppError('Semester already exists for this academic year', 409, 'DUPLICATE_SEMESTER');
    }
  }

  if (is_current) {
    db.prepare('UPDATE semesters SET is_current = 0 WHERE academic_year_id = ?').run(semester.academic_year_id);
  }

  const updates = [];
  const params = [];
  if (name) { updates.push('name = ?'); params.push(name); }
  if (start_date) { updates.push('start_date = ?'); params.push(start_date); }
  if (end_date) { updates.push('end_date = ?'); params.push(end_date); }
  if (is_current !== undefined) { updates.push('is_current = ?'); params.push(is_current ? 1 : 0); }
  if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }

  if (updates.length) {
    params.push(id);
    db.prepare(`UPDATE semesters SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }

  const updated = db.prepare('SELECT * FROM semesters WHERE id = ?').get(id);
  res.json({ success: true, message: 'Semester updated successfully', data: updated });
});

export const deleteSemester = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const semester = db.prepare('SELECT * FROM semesters WHERE id = ?').get(id);
  if (!semester) {
    throw new AppError('Semester not found', 404, 'SEMESTER_NOT_FOUND');
  }

  db.prepare('DELETE FROM semesters WHERE id = ?').run(id);
  res.json({ success: true, message: 'Semester deleted successfully' });
});

export const getSettings = asyncHandler(async (req, res) => {
  const settings = db.prepare('SELECT key, value, description FROM system_settings').all();
  const settingsMap = {};
  settings.forEach(s => { settingsMap[s.key] = s.value; });

  res.json({ success: true, data: settingsMap });
});

export const updateSettings = asyncHandler(async (req, res) => {
  const updates = req.body;

  if (typeof updates !== 'object' || Array.isArray(updates)) {
    throw new AppError('Settings must be an object of key-value pairs', 400, 'INVALID_SETTINGS');
  }

  const now = formatDate();
  for (const [key, value] of Object.entries(updates)) {
    db.prepare(`
      INSERT INTO system_settings (key, value, updated_at)
      VALUES (?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    `).run(key, String(value), now);
  }

  logActivity(req.user.id, 'settings.updated', 'settings', null, `Updated settings: ${Object.keys(updates).join(', ')}`, req.ip, req.get('user-agent'));

  const settings = db.prepare('SELECT key, value FROM system_settings').all();
  const settingsMap = {};
  settings.forEach(s => { settingsMap[s.key] = s.value; });

  res.json({ success: true, message: 'Settings updated successfully', data: settingsMap });
});

export const getAssessmentSheets = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, status, class_id, subject_id } = req.query;
  const { limit: lim, offset } = paginate(page, limit);

  const conditions = [];
  const params = [];

  if (status) { conditions.push('asheet.status = ?'); params.push(status); }
  if (class_id) { conditions.push('asheet.class_id = ?'); params.push(class_id); }
  if (subject_id) { conditions.push('asheet.subject_id = ?'); params.push(subject_id); }

  const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const sheets = db.prepare(`
    SELECT asheet.*,
      c.name as class_name, c.code as class_code,
      s.name as subject_name, s.code as subject_code,
      t.id as teacher_id, u.full_name as teacher_name,
      sem.name as semester, ay.name as academic_year,
      approver.full_name as approved_by_name,
      COUNT(ai.id) as item_count
    FROM assessment_sheets asheet
    JOIN classes c ON asheet.class_id = c.id
    JOIN subjects s ON asheet.subject_id = s.id
    JOIN teachers t ON asheet.teacher_id = t.id
    JOIN users u ON t.user_id = u.id
    JOIN semesters sem ON asheet.semester_id = sem.id
    JOIN academic_years ay ON asheet.academic_year_id = ay.id
    LEFT JOIN users approver ON asheet.approved_by = approver.id
    LEFT JOIN assessment_items ai ON asheet.id = ai.assessment_sheet_id
    ${whereClause}
    GROUP BY asheet.id
    ORDER BY asheet.updated_at DESC
    LIMIT ? OFFSET ?
  `).all(...params, lim, offset);

  const total = db.prepare(`
    SELECT COUNT(DISTINCT asheet.id) as count
    FROM assessment_sheets asheet
    ${whereClause}
  `).get(...params).count;

  res.json({
    success: true,
    data: sheets,
    pagination: { page: parseInt(page), limit: lim, total, totalPages: Math.ceil(total / lim) }
  });
});

export const approveAssessmentSheet = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const sheet = db.prepare('SELECT * FROM assessment_sheets WHERE id = ?').get(id);
  if (!sheet) {
    throw new AppError('Assessment sheet not found', 404, 'ASSESSMENT_NOT_FOUND');
  }

  if (sheet.status === 'approved') {
    throw new AppError('Assessment sheet already approved', 400, 'ALREADY_APPROVED');
  }

  const now = formatDate();
  db.prepare(`
    UPDATE assessment_sheets SET status = 'approved', approved_by = ?, approved_at = ?, updated_at = ?
    WHERE id = ?
  `).run(req.user.id, now, now, id);

  const updated = db.prepare(`
    SELECT asheet.*, c.name as class_name, s.name as subject_name,
      sem.name as semester, ay.name as academic_year
    FROM assessment_sheets asheet
    JOIN classes c ON asheet.class_id = c.id
    JOIN subjects s ON asheet.subject_id = s.id
    JOIN semesters sem ON asheet.semester_id = sem.id
    JOIN academic_years ay ON asheet.academic_year_id = ay.id
    WHERE asheet.id = ?
  `).get(id);

  logActivity(req.user.id, 'assessment.approved', 'assessment_sheet', id,
    `Approved assessment sheet for ${updated.class_name} - ${updated.subject_name}`, req.ip, req.get('user-agent'));

  res.json({ success: true, message: 'Assessment sheet approved successfully', data: updated });
});

export const rejectAssessmentSheet = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { rejection_reason } = req.body;

  const sheet = db.prepare('SELECT * FROM assessment_sheets WHERE id = ?').get(id);
  if (!sheet) {
    throw new AppError('Assessment sheet not found', 404, 'ASSESSMENT_NOT_FOUND');
  }

  const now = formatDate();
  db.prepare(`
    UPDATE assessment_sheets SET status = 'rejected', rejection_reason = ?, rejected_at = ?, updated_at = ?
    WHERE id = ?
  `).run(rejection_reason || 'Rejected by administrator', now, now, id);

  logActivity(req.user.id, 'assessment.rejected', 'assessment_sheet', id,
    `Rejected assessment sheet ${id}`, req.ip, req.get('user-agent'));

  res.json({ success: true, message: 'Assessment sheet rejected successfully' });
});

export default {
  getDashboardStats,
  getActivityLogs,
  getAllUsers,
  activateUser,
  deactivateUser,
  getAllAcademicYears,
  getAcademicYearById,
  createAcademicYear,
  updateAcademicYear,
  deleteAcademicYear,
  getAllSemesters,
  createSemester,
  updateSemester,
  deleteSemester,
  getSettings,
  updateSettings,
  getAssessmentSheets,
  approveAssessmentSheet,
  rejectAssessmentSheet
};
