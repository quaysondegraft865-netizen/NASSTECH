import { verifyAccessToken, extractTokenFromHeader } from '../utils/helpers.js';
import db from '../config/database.js';

export function authenticate(requiredRoles = []) {
  return (req, res, next) => {
    const token = extractTokenFromHeader(req.headers.authorization);
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
        code: 'UNAUTHORIZED'
      });
    }

    const decoded = verifyAccessToken(token);
    
    if (!decoded) {
      return res.status(401).json({
        success: false,
        message: 'Invalid or expired token',
        code: 'INVALID_TOKEN'
      });
    }

    // Check if user exists and is active
    const user = db.prepare('SELECT id, email, role, is_active FROM users WHERE id = ?').get(decoded.id);
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User not found',
        code: 'USER_NOT_FOUND'
      });
    }

    if (!user.is_active) {
      return res.status(403).json({
        success: false,
        message: 'Account is deactivated',
        code: 'ACCOUNT_DEACTIVATED'
      });
    }

    // Check role permissions
    if (requiredRoles.length > 0 && !requiredRoles.includes(user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions',
        code: 'FORBIDDEN'
      });
    }

    req.user = user;
    next();
  };
}

export function optionalAuth(req, res, next) {
  const token = extractTokenFromHeader(req.headers.authorization);
  
  if (token) {
    const decoded = verifyAccessToken(token);
    if (decoded) {
      const user = db.prepare('SELECT id, email, role, is_active FROM users WHERE id = ?').get(decoded.id);
      if (user && user.is_active) {
        req.user = user;
      }
    }
  }
  
  next();
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
        code: 'UNAUTHORIZED'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions',
        code: 'FORBIDDEN'
      });
    }

    next();
  };
}

export function requireStudent() {
  return (req, res, next) => {
    if (!req.user || req.user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Student access required',
        code: 'FORBIDDEN'
      });
    }
    next();
  };
}

export function requireTeacher() {
  return (req, res, next) => {
    const teacherRoles = ['teacher', 'form_master', 'hod'];
    if (!req.user || !teacherRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Teacher access required',
        code: 'FORBIDDEN'
      });
    }
    next();
  };
}

export function requireAdmin() {
  return (req, res, next) => {
    const adminRoles = ['staff', 'super_admin'];
    if (!req.user || !adminRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Admin access required',
        code: 'FORBIDDEN'
      });
    }
    next();
  };
}

export function requireSuperAdmin() {
  return (req, res, next) => {
    if (!req.user || req.user.role !== 'super_admin') {
      return res.status(403).json({
        success: false,
        message: 'Super admin access required',
        code: 'FORBIDDEN'
      });
    }
    next();
  };
}